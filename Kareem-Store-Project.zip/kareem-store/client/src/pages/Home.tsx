import {
  ArrowDown,
  ArrowUpRight,
  Check,
  ChevronDown,
  Heart,
  Leaf,
  MessageCircle,
  Search,
  ShieldCheck,
  Truck,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  DEMO_PRODUCTS,
  type CatalogProduct,
  type ProductCategory,
} from "../../../shared/products";
import { StoreHeader } from "@/components/StoreHeader";
import { ProductCard, money } from "@/components/ProductCard";
import { useLocale } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";

const heroImage = "/images/thermora-hero.webp";

export default function Home() {
  const { locale, t } = useLocale();
  const [category, setCategory] = useState<"all" | ProductCategory>("all");
  const [brandFilter, setBrandFilter] = useState("");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("featured");
  const productsQuery = trpc.store.products.useQuery(undefined, {
    placeholderData: DEMO_PRODUCTS as CatalogProduct[],
  });
  const products = productsQuery.data ?? DEMO_PRODUCTS;
  const bestSellersQuery = trpc.store.bestSellers.useQuery();
  const settingsQuery = trpc.store.settings.useQuery();
  const phone = settingsQuery.data?.whatsappNumber?.replace(/\D/g, "") ?? "";
  useEffect(() => {
    const focus = () => document.getElementById("product-search")?.focus();
    window.addEventListener("thermora-search-focus", focus);
    return () => window.removeEventListener("thermora-search-focus", focus);
  }, []);
  const filtered = useMemo(() => {
    let list = products.filter(product => {
      const matchesCategory =
        category === "all" || product.category === category;
      const matchesBrand =
        !brandFilter ||
        product.brandEn.trim().toLocaleLowerCase("en") === brandFilter;
      return matchesCategory && matchesBrand;
    });
    const normalized = query
      .trim()
      .toLocaleLowerCase(locale === "fa" ? "fa-AF" : "en-AF");
    if (normalized)
      list = list.filter(product =>
        [
          product.nameFa,
          product.nameEn,
          product.brandFa,
          product.brandEn,
          product.descriptionFa,
          product.descriptionEn,
          product.colorsFa,
          product.colorsEn,
        ]
          .join(" ")
          .toLocaleLowerCase()
          .includes(normalized)
      );
    if (sort === "low") list = [...list].sort((a, b) => a.price - b.price);
    if (sort === "high") list = [...list].sort((a, b) => b.price - a.price);
    if (sort === "featured")
      list = [...list].sort((a, b) => Number(b.featured) - Number(a.featured));
    return list;
  }, [products, category, brandFilter, query, sort, locale]);
  const brandCollections = useMemo(() => {
    const grouped = new Map<
      string,
      { nameFa: string; nameEn: string; count: number }
    >();
    for (const product of products) {
      const key = product.brandEn.trim().toLocaleLowerCase("en");
      if (product.isDemo || !key) continue;
      const group = grouped.get(key);
      if (group) group.count += 1;
      else
        grouped.set(key, {
          nameFa: product.brandFa,
          nameEn: product.brandEn,
          count: 1,
        });
    }
    return [...grouped.entries()]
      .map(([key, brand]) => ({ key, ...brand }))
      .slice(0, 6);
  }, [products]);
  const newArrivals = useMemo(
    () =>
      [...products]
        .sort((left, right) => {
          const leftTime = left.createdAt
            ? new Date(left.createdAt).getTime()
            : 0;
          const rightTime = right.createdAt
            ? new Date(right.createdAt).getTime()
            : 0;
          return rightTime - leftTime;
        })
        .slice(0, 3),
    [products]
  );
  const bestSellers = useMemo(() => {
    const bySlug = new Map(products.map(product => [product.slug, product]));
    return (bestSellersQuery.data ?? [])
      .map(item => bySlug.get(item.slug))
      .filter((product): product is CatalogProduct => Boolean(product));
  }, [bestSellersQuery.data, products]);
  const categories: { id: "all" | ProductCategory; label: string }[] = [
    { id: "all", label: t.all },
    { id: "thermos", label: t.thermos },
    { id: "tea", label: t.tea },
    { id: "travel", label: t.travel },
  ];
  const whatsapp = phone ? `https://wa.me/${phone}` : "";
  const english = locale === "en";

  return (
    <div className="site-shell" id="top">
      <StoreHeader />
      <main>
        <section className="hero-section">
          <div className="hero-image-wrap">
            <img
              src={heroImage}
              alt={
                english
                  ? "Forest-green flask in warm late-afternoon light"
                  : "فلاسک سبز جنگلی در نور آرام عصر"
              }
            />
            <div className="hero-image-tint" />
            <span className="hero-image-tag">
              <Leaf size={14} />
              {english ? "A slower kind of everyday" : "آرامشِ کوچکِ هر روز"}
            </span>
          </div>
          <div className="hero-copy">
            <div className="hero-prelude">
              <span className="gold-line" />
              {t.heroEyebrow}
            </div>
            <h1>{t.heroTitle}</h1>
            <p>{t.heroBody}</p>
            <div className="hero-actions">
              <a className="button button-green" href="#products">
                {t.browse}
                <ArrowUpRight size={17} />
              </a>
              {whatsapp ? (
                <a
                  className="button button-quiet"
                  href={`${whatsapp}?text=${encodeURIComponent(english ? "Hello, I'd like to ask about your flasks." : "سلام، دربارهٔ فلاسک‌ها پرسش دارم.")}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <MessageCircle size={16} />
                  {t.whatsapp}
                </a>
              ) : (
                <a className="button button-quiet" href="#products">
                  <ArrowDown size={16} />
                  {t.seeAll}
                </a>
              )}
            </div>
            <div className="hero-trust">
              <span>
                <Check size={14} />
                {t.noAccount}
              </span>
              <i />
              <span>
                <Check size={14} />
                {t.demo}
              </span>
            </div>
          </div>
          <div className="hero-index">
            <span>01</span>
            <i />
            <span>04</span>
          </div>
        </section>
        <section className="intro-strip">
          <div>
            <span className="eyebrow">{t.newLabel}</span>
            <h2>{t.collectionTitle}</h2>
          </div>
          <p>{t.collectionBody}</p>
          <span className="strip-sun" aria-hidden="true">
            ◒
          </span>
        </section>
        <section
          className="collection-section page-section"
          aria-labelledby="collection-paths-title"
        >
          <div className="collection-section-head">
            <span className="eyebrow">
              KAREEM STORE ·{" "}
              {english ? "CURATED FOR EVERYDAY" : "انتخاب برای هر روز"}
            </span>
            <h2 id="collection-paths-title">
              {english ? "Choose by the moment" : "بر اساس نیاز انتخاب کن"}
            </h2>
          </div>
          <div className="collection-paths">
            {[
              {
                category: "thermos" as const,
                number: "01",
                title: english ? "Everyday flasks" : "فلاسک‌های روزمره",
                detail: english
                  ? "A simple companion for tea and water."
                  : "همراه سادهٔ چای و آب در روز.",
              },
              {
                category: "tea" as const,
                number: "02",
                title: english ? "Tea on the road" : "چای‌دمِ همراه",
                detail: english
                  ? "Browse tea flask demo designs."
                  : "طرح‌های نمونهٔ فلاسک چای را ببین.",
              },
              {
                category: "travel" as const,
                number: "03",
                title: english ? "Light for the journey" : "سبک برای سفر",
                detail: english
                  ? "Smaller sample pieces for your bag."
                  : "نمونه‌های کوچک برای هم‌سفری.",
              },
            ].map(collection => (
              <a
                key={collection.category}
                href="#products"
                className="collection-path-card"
                onClick={() => {
                  setBrandFilter("");
                  setCategory(collection.category);
                }}
              >
                <span>{collection.number}</span>
                <div>
                  <b>{collection.title}</b>
                  <small>{collection.detail}</small>
                </div>
                <ArrowUpRight size={18} />
              </a>
            ))}
          </div>
        </section>
        <section
          className="brand-collection-section page-section"
          aria-labelledby="brand-collections-title"
        >
          <div className="collection-section-head">
            <span className="eyebrow">
              {english ? "VERIFIED MAKERS" : "سازندگان تأییدشده"}
            </span>
            <h2 id="brand-collections-title">
              {english ? "Brand collections" : "مجموعه‌های برندها"}
            </h2>
          </div>
          {brandCollections.length ? (
            <div className="collection-paths">
              {brandCollections.map((brand, index) => (
                <a
                  key={brand.key}
                  href="#products"
                  className="collection-path-card"
                  onClick={() => {
                    setCategory("all");
                    setBrandFilter(brand.key);
                  }}
                >
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <div>
                    <b>{english ? brand.nameEn : brand.nameFa}</b>
                    <small>
                      {new Intl.NumberFormat(
                        english ? "en-AF" : "fa-AF"
                      ).format(brand.count)}{" "}
                      {t.productCount}
                    </small>
                  </div>
                  <ArrowUpRight size={18} />
                </a>
              ))}
            </div>
          ) : (
            <p className="best-sellers-empty">
              {english
                ? "Brand collections appear when the shop adds products with verified makers. Demo entries never invent a brand."
                : "مجموعه‌های برند پس از افزودن سازندهٔ تأییدشده نمایش داده می‌شوند؛ برای کالای نمونه نام برند نمی‌سازیم."}
            </p>
          )}
        </section>
        <section className="catalog-section page-section" id="products">
          <div className="section-heading">
            <div>
              <span className="eyebrow">KAREEM STORE · KABUL</span>
              <h2>{t.featured}</h2>
            </div>
            <span className="results-count">
              {new Intl.NumberFormat(english ? "en-AF" : "fa-AF").format(
                filtered.length
              )}{" "}
              {t.productCount}
            </span>
          </div>
          <div className="catalog-tools">
            <div
              className="filter-pills"
              role="group"
              aria-label={t.categories}
            >
              {categories.map(item => (
                <button
                  key={item.id}
                  className={`filter-pill ${category === item.id && !brandFilter ? "active" : ""}`}
                  onClick={() => {
                    setBrandFilter("");
                    setCategory(item.id);
                  }}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="catalog-actions">
              <label className="search-field">
                <Search size={17} />
                <input
                  id="product-search"
                  value={query}
                  onChange={event => setQuery(event.target.value)}
                  placeholder={t.search}
                />
                {query && (
                  <button
                    onClick={() => setQuery("")}
                    aria-label="clear search"
                  >
                    ×
                  </button>
                )}
              </label>
              <label className="sort-field">
                <span>{t.sort}</span>
                <select
                  value={sort}
                  onChange={event => setSort(event.target.value)}
                >
                  <option value="featured">{t.sortFeatured}</option>
                  <option value="low">{t.sortLow}</option>
                  <option value="high">{t.sortHigh}</option>
                </select>
                <ChevronDown size={14} />
              </label>
            </div>
          </div>
          <div className="product-grid">
            {filtered.map((product, index) => (
              <ProductCard key={product.slug} product={product} index={index} />
            ))}
          </div>
          {filtered.length === 0 && (
            <div className="empty-results">
              <span>⌕</span>
              <h3>{english ? "No match just yet" : "چیزی پیدا نشد"}</h3>
              <p>
                {english
                  ? "Try another word or clear the category."
                  : "واژه‌ای دیگر بنویس یا دسته‌بندی را تغییر بده."}
              </p>
              <button
                className="button button-outline"
                onClick={() => {
                  setQuery("");
                  setBrandFilter("");
                  setCategory("all");
                }}
              >
                {t.all}
              </button>
            </div>
          )}
          <p className="sample-disclaimer">
            <ShieldCheck size={16} />
            {t.demo}
          </p>
        </section>
        <section
          className="new-arrivals-section page-section"
          aria-labelledby="new-arrivals-title"
        >
          <div className="section-heading">
            <div>
              <span className="eyebrow">
                {english ? "JUST ADDED" : "به‌تازگی افزوده‌شده"}
              </span>
              <h2 id="new-arrivals-title">
                {english ? "New arrivals" : "کالاهای تازه"}
              </h2>
            </div>
            <span className="results-count">{t.demo}</span>
          </div>
          <div className="product-grid">
            {newArrivals.map((product, index) => (
              <ProductCard key={product.slug} product={product} index={index} />
            ))}
          </div>
        </section>
        <section
          className="best-sellers-section page-section"
          aria-labelledby="best-sellers-title"
        >
          <div className="section-heading">
            <div>
              <span className="eyebrow">
                {english ? "CONFIRMED ORDERS" : "سفارش‌های تأییدشده"}
              </span>
              <h2 id="best-sellers-title">
                {english ? "Best sellers" : "پرفروش‌ها"}
              </h2>
            </div>
          </div>
          {bestSellers.length > 0 ? (
            <div className="product-grid">
              {bestSellers.map((product, index) => (
                <ProductCard
                  key={product.slug}
                  product={product}
                  index={index}
                />
              ))}
            </div>
          ) : (
            <p className="best-sellers-empty">
              {english
                ? "Real best sellers will appear after the shop confirms orders. This demo does not invent sales."
                : "پرفروش‌های واقعی پس از تأیید سفارش‌ها نمایش داده می‌شوند؛ در این دمو فروش ساختگی نشان نمی‌دهیم."}
            </p>
          )}
        </section>
        <section className="story-section page-section" id="story">
          <div className="story-visual">
            <img
              src="/images/products/shabnam-tea.webp"
              alt=""
              loading="lazy"
            />
            <span className="story-stamp">
              <Leaf size={17} />
              {english ? "Simple by nature" : "ساده، از آغاز"}
            </span>
          </div>
          <div className="story-copy">
            <span className="eyebrow">
              {english ? "FOR THE WAY YOU LIVE" : "برای راهی که می‌روی"}
            </span>
            <h2>{t.benefits}</h2>
            <p className="story-lede">{t.collectionBody}</p>
            <div className="benefit-list">
              <div>
                <span>
                  <Heart size={19} />
                </span>
                <div>
                  <b>{t.benefit1}</b>
                  <p>{t.benefit1Text}</p>
                </div>
              </div>
              <div>
                <span>
                  <ShieldCheck size={19} />
                </span>
                <div>
                  <b>{t.benefit2}</b>
                  <p>{t.benefit2Text}</p>
                </div>
              </div>
              <div>
                <span>
                  <MessageCircle size={19} />
                </span>
                <div>
                  <b>{t.benefit3}</b>
                  <p>{t.benefit3Text}</p>
                </div>
              </div>
            </div>
            <a className="text-link" href="#products">
              {t.browse}
              <ArrowUpRight size={17} />
            </a>
          </div>
        </section>
        <section className="reviews-section page-section">
          <div className="reviews-heading">
            <span className="eyebrow">
              {english ? "A NOTE FROM THE SHOP" : "روایتی از خرید"}
            </span>
            <h2>{t.testimonial}</h2>
            <p>{t.testimonialNote}</p>
          </div>
          <div className="review-grid">
            {[t.review1, t.review2, t.review3].map((review, i) => (
              <blockquote className="review-card" key={review}>
                <div className="review-stars" aria-label="نمونه">
                  ★★★★★
                </div>
                <p>“{review}”</p>
                <footer>
                  <span className="review-avatar">{["س", "م", "ن"][i]}</span>
                  <span>
                    {english
                      ? `Sample customer ${i + 1}`
                      : `خریدار نمونه ${i + 1}`}
                    <small>{t.sample}</small>
                  </span>
                  <Check size={15} />
                </footer>
              </blockquote>
            ))}
          </div>
        </section>
        <section className="faq-section page-section" id="faq">
          <div className="faq-heading">
            <span className="eyebrow">
              {english ? "A FEW QUICK ANSWERS" : "پاسخ‌های کوتاه و روشن"}
            </span>
            <h2>{t.faqTitle}</h2>
          </div>
          <div className="faq-list">
            {[
              [t.faq1, t.faq1a],
              [t.faq2, t.faq2a],
              [t.faq3, t.faq3a],
            ].map(([question, answer], i) => (
              <details key={question} className="faq-item" open={i === 0}>
                <summary>
                  <span className="faq-number">0{i + 1}</span>
                  <b>{question}</b>
                  <span className="faq-plus" />
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </section>
        <section className="final-note">
          <div>
            <span className="eyebrow">KAREEM STORE · KABUL</span>
            <h2>{t.about}</h2>
            <p>{t.deliveryNote}</p>
          </div>
          {whatsapp && (
            <a
              className="button button-cream"
              href={`${whatsapp}?text=${encodeURIComponent(english ? "Hello Kareem Store" : "سلام کریم ستور")}`}
              target="_blank"
              rel="noreferrer"
            >
              <MessageCircle size={16} />
              {t.whatsapp}
            </a>
          )}
        </section>
      </main>
      <footer className="site-footer">
        <div className="footer-inner">
          <div className="footer-brand">
            <span className="brand-symbol">
              <svg viewBox="0 0 44 44" fill="none">
                <circle
                  cx="22"
                  cy="22"
                  r="19"
                  stroke="currentColor"
                  strokeWidth="1.25"
                />
                <path
                  d="M16 29h12M18 26c-3-5 6-6 2-12M23 25c-2-4 6-6 3-11M16 21c0-2 1-4 3-6"
                  stroke="currentColor"
                  strokeWidth="1.35"
                  strokeLinecap="round"
                />
              </svg>
            </span>
            <strong>Kareem Store</strong>
            <p>{t.footerNote}</p>
          </div>
          <div className="footer-links">
            <a href="#products">{t.shop}</a>
            <a href="#faq">{t.faq}</a>
            <a href="/login">{t.admin}</a>
          </div>
          <div className="footer-location">
            <span>
              <Truck size={16} />
              {english
                ? "Delivery arranged locally"
                : "هماهنگی تحویل با فروشگاه"}
            </span>
            <small>
              © {new Date().getFullYear()} KAREEM STORE —{" "}
              {english ? "Kabul, Afghanistan" : "کابل، افغانستان"}
            </small>
          </div>
        </div>
        <div className="footer-bottom">
          <span>{t.demo}</span>
          <a href="#top">↑</a>
        </div>
      </footer>
    </div>
  );
}
