import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Camera,
  Check,
  ChevronDown,
  CircleAlert,
  ClipboardList,
  ImagePlus,
  LogOut,
  Package,
  Pencil,
  Plus,
  Save,
  Settings2,
  ShoppingBag,
  Trash2,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import type { CatalogProduct, ProductCategory } from "../../../shared/products";
import { DEFAULT_SETTINGS } from "../../../shared/products";
import type { OrderStatus } from "../../../drizzle/schema";
import { BrandMark } from "@/components/StoreHeader";
import { money } from "@/components/ProductCard";
import { useLocale } from "@/lib/i18n";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

const blankProduct = (): CatalogProduct => ({
  slug: "",
  nameFa: "",
  nameEn: "",
  descriptionFa: "",
  descriptionEn: "",
  brandFa: "",
  brandEn: "",
  originFa: "",
  originEn: "",
  capacityMl: 500,
  dimensionsFa: "",
  dimensionsEn: "",
  materialFa: "",
  materialEn: "",
  insulationFa: "",
  insulationEn: "",
  colorsFa: "",
  colorsEn: "",
  price: 0,
  stock: 0,
  imageUrl: "",
  galleryUrls: [],
  category: "thermos",
  featured: false,
  isDemo: true,
});
const statuses: OrderStatus[] = [
  "new",
  "confirmed",
  "shipped",
  "completed",
  "cancelled",
];
const statusText = (status: OrderStatus, english: boolean) =>
  ({
    new: english ? "New" : "جدید",
    confirmed: english ? "Confirmed" : "تأیید شد",
    shipped: english ? "In transit" : "در مسیر",
    completed: english ? "Complete" : "تکمیل شد",
    cancelled: english ? "Cancelled" : "لغو شد",
  })[status];

export default function AdminPage() {
  const { locale } = useLocale();
  const english = locale === "en";
  const auth = useAuth();
  const [tab, setTab] = useState<"products" | "orders" | "settings">(
    "products"
  );
  const [form, setForm] = useState<CatalogProduct>(blankProduct());
  const [editing, setEditing] = useState(false);
  const [notice, setNotice] = useState("");
  const [settingsForm, setSettingsForm] = useState(DEFAULT_SETTINGS);
  const canManage = auth.user?.role === "admin";
  const products = trpc.store.admin.products.useQuery(undefined, {
    enabled: canManage,
  });
  const orders = trpc.store.admin.orders.useQuery(undefined, {
    enabled: canManage,
  });
  const settings = trpc.store.admin.settings.useQuery(undefined, {
    enabled: canManage,
  });
  const utils = trpc.useUtils();
  const refresh = async () => {
    await Promise.all([
      utils.store.admin.products.invalidate(),
      utils.store.admin.orders.invalidate(),
      utils.store.admin.settings.invalidate(),
      utils.store.products.invalidate(),
      utils.store.settings.invalidate(),
    ]);
  };
  const saveProduct = trpc.store.admin.saveProduct.useMutation({
    onSuccess: async () => {
      await refresh();
      setNotice(english ? "Product saved." : "کالا ذخیره شد.");
      setForm(blankProduct());
      setEditing(false);
    },
    onError: () =>
      setNotice(
        english
          ? "Could not save. Check the fields and database setup."
          : "ذخیره نشد؛ خانه‌ها و فعال‌بودن پایگاه‌داده را بررسی کنید."
      ),
  });
  const removeProduct = trpc.store.admin.removeProduct.useMutation({
    onSuccess: refresh,
    onError: () =>
      setNotice(english ? "Could not remove item." : "حذف کالا انجام نشد."),
  });
  const updateOrder = trpc.store.admin.updateOrder.useMutation({
    onSuccess: refresh,
    onError: () =>
      setNotice(
        english ? "Could not update order." : "به‌روزرسانی سفارش انجام نشد."
      ),
  });
  const saveSettings = trpc.store.admin.saveSettings.useMutation({
    onSuccess: async () => {
      await refresh();
      setNotice(english ? "Shop details saved." : "تنظیمات فروشگاه ذخیره شد.");
    },
    onError: () =>
      setNotice(
        english ? "Could not save shop details." : "تنظیمات ذخیره نشد."
      ),
  });
  const uploadImage = trpc.store.admin.uploadImage.useMutation({
    onError: () =>
      setNotice(
        english
          ? "Image upload failed. Ensure project storage is available and the file is under 5 MB."
          : "بارگذاری تصویر انجام نشد. فضای ذخیره را بررسی کنید؛ حجم عکس باید زیر ۵ مگابایت باشد."
      ),
  });
  useEffect(() => {
    if (settings.data)
      setSettingsForm({
        storeNameFa: settings.data.storeNameFa,
        storeNameEn: settings.data.storeNameEn,
        whatsappNumber: settings.data.whatsappNumber,
        noticeFa: settings.data.noticeFa,
        noticeEn: settings.data.noticeEn,
      });
  }, [settings.data]);
  const ordersList = orders.data ?? [];
  const counts = useMemo(
    () => ({
      products: products.data?.length ?? 0,
      orders: ordersList.length,
      new: ordersList.filter(order => order.status === "new").length,
    }),
    [products.data, ordersList]
  );
  const change = (
    key: keyof CatalogProduct,
    value: string | number | boolean
  ) => setForm(old => ({ ...old, [key]: value }));
  const editProduct = (product: CatalogProduct) => {
    const galleryUrls = [
      ...new Set([product.imageUrl, ...(product.galleryUrls ?? [])]),
    ].slice(0, 8);
    setForm({ ...product, imageUrl: galleryUrls[0], galleryUrls });
    setEditing(true);
    setNotice("");
    document
      .getElementById("product-editor")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const handleImage = async (file?: File): Promise<boolean> => {
    if (!file) return false;
    if (
      !["image/png", "image/jpeg", "image/webp"].includes(file.type) ||
      file.size > 5 * 1024 * 1024
    ) {
      setNotice(
        english
          ? "Choose a PNG, JPEG or WebP smaller than 5 MB."
          : "عکس PNG، JPEG یا WebP با حجم زیر ۵ مگابایت انتخاب کنید."
      );
      return false;
    }
    const base64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("File read failed"));
      reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
      reader.readAsDataURL(file);
    });
    try {
      const uploaded = await uploadImage.mutateAsync({
        filename: file.name,
        mime: file.type as "image/png" | "image/jpeg" | "image/webp",
        base64,
      });
      setForm(old => {
        const current = old.galleryUrls?.length
          ? old.galleryUrls
          : old.imageUrl
            ? [old.imageUrl]
            : [];
        if (current.includes(uploaded.imageUrl)) return old;
        const galleryUrls = [...current, uploaded.imageUrl].slice(0, 8);
        return {
          ...old,
          imageUrl: old.imageUrl || uploaded.imageUrl,
          galleryUrls,
        };
      });
      setNotice(
        english ? "Photo added to gallery." : "عکس به گالری افزوده شد."
      );
      return true;
    } catch {
      /* mutation displays the error */
      return false;
    }
  };
  const handleImages = async (files: File[]) => {
    let remaining = Math.max(
      0,
      8 - (form.galleryUrls?.length ?? (form.imageUrl ? 1 : 0))
    );
    if (remaining === 0) {
      setNotice(
        english
          ? "A product can have up to 8 photos."
          : "برای هر کالا حداکثر ۸ عکس مجاز است."
      );
      return;
    }
    for (const file of files) {
      if (remaining === 0) {
        setNotice(
          english
            ? "A product can have up to 8 photos."
            : "برای هر کالا حداکثر ۸ عکس مجاز است."
        );
        break;
      }
      if (await handleImage(file)) remaining -= 1;
    }
  };
  const submitProduct = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setNotice("");
    const images = [...new Set(form.galleryUrls ?? [])];
    if (!images.length) {
      setNotice(
        english
          ? "Upload at least one product photo."
          : "لطفاً دست‌کم یک عکس کالا بارگذاری کنید."
      );
      return;
    }
    const mainImage = images.includes(form.imageUrl)
      ? form.imageUrl
      : images[0];
    const galleryUrls = [
      mainImage,
      ...images.filter(image => image !== mainImage),
    ];
    saveProduct.mutate({
      ...form,
      imageUrl: mainImage,
      galleryUrls,
      slug: form.slug.trim().toLowerCase().replace(/\s+/g, "-"),
      category: form.category as ProductCategory,
    });
  };
  const field = (
    key: keyof CatalogProduct,
    label: string,
    type = "text",
    required = true
  ) => (
    <label className="admin-field" key={key}>
      <span>{label}</span>
      <input
        value={String(form[key] ?? "")}
        type={type}
        required={required}
        min={type === "number" ? 0 : undefined}
        onChange={event =>
          change(
            key,
            type === "number" ? Number(event.target.value) : event.target.value
          )
        }
      />
    </label>
  );

  if (auth.loading)
    return (
      <div className="admin-loading">
        {english ? "Checking manager access…" : "در حال بررسی دسترسی مدیر…"}
      </div>
    );
  if (!auth.user)
    return (
      <div className="admin-guard">
        <BrandMark />
        <span className="login-icon">
          <LockIcon />
        </span>
        <h1>{english ? "Manager sign-in required" : "ورود مدیر لازم است"}</h1>
        <p>
          {english
            ? "Shopper orders do not require sign-in. This page is private to the shop manager."
            : "برای مشتری حساب لازم نیست؛ این صفحه فقط برای مدیر فروشگاه است."}
        </p>
        <Link className="button button-green" href="/login">
          {english ? "Sign in" : "ورود مدیر"}
        </Link>
      </div>
    );
  if (!canManage)
    return (
      <div className="admin-guard">
        <BrandMark />
        <span className="guard-alert">
          <CircleAlert size={22} />
        </span>
        <h1>
          {english
            ? "Manager access has not been granted"
            : "دسترسی مدیریت ندارید"}
        </h1>
        <p>
          {english
            ? "Set OWNER_OPEN_ID to the shop owner's Manus identity in the project environment, then sign in again. Customer data is not exposed here."
            : "شناسهٔ حساب مدیر را در محیط پروژه در OWNER_OPEN_ID تنظیم کنید و دوباره وارد شوید. اطلاعات مشتری به این صفحه نمایش داده نمی‌شود."}
        </p>
        <button
          className="button button-outline"
          onClick={() => void auth.logout()}
        >
          {english ? "Sign out" : "خروج"}
        </button>
        <Link href="/" className="back-link">
          {english ? "Back to the shop" : "بازگشت به فروشگاه"}
        </Link>
      </div>
    );

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar">
        <BrandMark />
        <div className="manager-chip">
          <span className="manager-avatar">
            {(auth.user.name || "M").slice(0, 1)}
          </span>
          <span>
            <strong>
              {auth.user.name || (english ? "Manager" : "مدیر فروشگاه")}
            </strong>
            <small>{english ? "Shop manager" : "مدیر فروشگاه"}</small>
          </span>
        </div>
        <nav className="admin-menu">
          {(
            [
              [
                "products",
                Package,
                english ? "Products" : "کالاها",
                counts.products,
              ],
              [
                "orders",
                ClipboardList,
                english ? "Orders" : "سفارش‌ها",
                counts.new,
              ],
              [
                "settings",
                Settings2,
                english ? "Shop settings" : "تنظیم فروشگاه",
                null,
              ],
            ] as const
          ).map(([id, Icon, title, badge]) => (
            <button
              key={String(id)}
              className={tab === id ? "active" : ""}
              onClick={() => {
                setTab(id as typeof tab);
                setNotice("");
              }}
            >
              <Icon size={18} />
              <span>{String(title)}</span>
              {badge ? <b>{String(badge)}</b> : null}
            </button>
          ))}
        </nav>
        <div className="admin-side-foot">
          <span>
            <Activity size={15} />
            {english ? "Store desk" : "میز فروشگاه"}
          </span>
          <Link href="/">{english ? "← View the shop" : "→ دیدن فروشگاه"}</Link>
        </div>
      </aside>
      <main className="admin-main">
        <header className="admin-topbar">
          <div className="admin-breadcrumb">
            <span>KAREEM STORE</span>
            {english ? " / Manager desk" : " / مدیریت فروشگاه"}
          </div>
          <div className="admin-top-actions">
            <Link href="/" className="admin-view-shop">
              <ShoppingBag size={16} />
              {english ? "View shop" : "دیدن فروشگاه"}
            </Link>
            <button className="admin-logout" onClick={() => void auth.logout()}>
              <LogOut size={16} />
              <span>{english ? "Sign out" : "خروج"}</span>
            </button>
          </div>
        </header>
        <div className="admin-content">
          <div className="admin-title-row">
            <div>
              <span className="eyebrow">
                {english ? "THE SHOP DESK" : "میزِ مدیریت فروشگاه"}
              </span>
              <h1>
                {tab === "products"
                  ? english
                    ? "Your products"
                    : "کالاهای فروشگاه"
                  : tab === "orders"
                    ? english
                      ? "Customer orders"
                      : "سفارش‌های مشتریان"
                    : english
                      ? "Shop settings"
                      : "تنظیمات فروشگاه"}
              </h1>
              <p>
                {tab === "products"
                  ? english
                    ? "Manage listings, images, prices and stock."
                    : "کالا، تصویر، قیمت و موجودی را مدیریت کنید."
                  : tab === "orders"
                    ? english
                      ? "Guest orders, kept together for easy follow-up."
                      : "سفارش‌های مهمان برای پیگیری آسان در یک‌جا."
                    : english
                      ? "Set the direct contact details customers see."
                      : "راه تماس مستقیمی را که مشتری می‌بیند تنظیم کنید."}
              </p>
            </div>
            {tab === "products" && (
              <button
                className="button button-green"
                onClick={() => {
                  setForm(blankProduct());
                  setEditing(false);
                  document
                    .getElementById("product-editor")
                    ?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
              >
                <Plus size={17} />
                {english ? "Add product" : "افزودن کالا"}
              </button>
            )}
          </div>
          <div className="admin-stats">
            <div>
              <span>
                <Package size={17} />
                {english ? "Products" : "کالاها"}
              </span>
              <strong>{counts.products}</strong>
            </div>
            <div>
              <span>
                <ClipboardList size={17} />
                {english ? "Orders" : "سفارش‌ها"}
              </span>
              <strong>{counts.orders}</strong>
            </div>
            <div>
              <span>
                <Activity size={17} />
                {english ? "To confirm" : "در انتظار تأیید"}
              </span>
              <strong>{counts.new}</strong>
            </div>
          </div>
          {notice && (
            <div className="admin-notice" role="status">
              <Check size={16} />
              {notice}
              <button onClick={() => setNotice("")}>×</button>
            </div>
          )}
          {tab === "products" && (
            <div className="admin-products-view">
              <section className="admin-panel">
                <div className="panel-head">
                  <div>
                    <span className="eyebrow">
                      {english ? "CATALOGUE" : "فهرست کالا"}
                    </span>
                    <h2>{english ? "All listings" : "تمام کالاها"}</h2>
                  </div>
                  <span className="panel-count">{counts.products}</span>
                </div>
                {products.isLoading ? (
                  <div className="admin-empty">
                    {english ? "Loading catalogue…" : "در حال بارگیری فهرست…"}
                  </div>
                ) : products.error ? (
                  <div className="admin-empty form-error">
                    {english
                      ? "The catalogue database is not ready. Run the project migrations and sign in as the manager."
                      : "پایگاه‌دادهٔ کالا آماده نیست. مهاجرت پروژه را اجرا و با حساب مدیر وارد شوید."}
                  </div>
                ) : (
                  <div className="admin-table-wrap">
                    <table className="admin-table">
                      <thead>
                        <tr>
                          <th>{english ? "Product" : "کالا"}</th>
                          <th>{english ? "Price (AFN)" : "قیمت (AFN)"}</th>
                          <th>{english ? "Stock" : "موجودی"}</th>
                          <th>{english ? "Listing" : "برچسب"}</th>
                          <th>{english ? "Actions" : "کارها"}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(products.data ?? []).map(product => (
                          <tr key={product.slug}>
                            <td>
                              <div className="admin-product-cell">
                                <img src={product.imageUrl} alt="" />
                                <span>
                                  <strong>
                                    {english ? product.nameEn : product.nameFa}
                                  </strong>
                                  <small>{product.slug}</small>
                                </span>
                              </div>
                            </td>
                            <td>{money(product.price, locale)}</td>
                            <td>{product.stock}</td>
                            <td>
                              <span
                                className={`admin-tag ${product.isDemo ? "demo" : ""}`}
                              >
                                {product.isDemo
                                  ? english
                                    ? "DEMO"
                                    : "نمونه"
                                  : english
                                    ? "Ready"
                                    : "واقعی"}
                              </span>
                            </td>
                            <td>
                              <div className="row-actions">
                                <button
                                  onClick={() =>
                                    editProduct(product as CatalogProduct)
                                  }
                                  aria-label={english ? "Edit" : "ویرایش"}
                                >
                                  <Pencil size={15} />
                                </button>
                                <button
                                  onClick={() => {
                                    if (
                                      window.confirm(
                                        english
                                          ? "Remove this product?"
                                          : "این کالا حذف شود؟"
                                      )
                                    )
                                      removeProduct.mutate({
                                        slug: product.slug,
                                      });
                                  }}
                                  aria-label={english ? "Remove" : "حذف"}
                                >
                                  <Trash2 size={15} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </section>
              <section className="admin-panel" id="product-editor">
                <div className="panel-head">
                  <div>
                    <span className="eyebrow">
                      {editing
                        ? english
                          ? "EDIT LISTING"
                          : "ویرایش کالا"
                        : english
                          ? "NEW LISTING"
                          : "کالای تازه"}
                    </span>
                    <h2>
                      {editing
                        ? english
                          ? "Update product"
                          : "به‌روزرسانی کالا"
                        : english
                          ? "Add a product"
                          : "افزودن یک کالا"}
                    </h2>
                  </div>
                  {editing && (
                    <button
                      className="admin-cancel"
                      onClick={() => {
                        setEditing(false);
                        setForm(blankProduct());
                      }}
                    >
                      {english ? "Cancel" : "لغو"}
                    </button>
                  )}
                </div>
                <form className="product-edit-form" onSubmit={submitProduct}>
                  <div className="form-section-label">
                    <span>01</span>
                    {english ? "Basic information" : "اطلاعات اصلی"}
                  </div>
                  <div className="admin-form-grid">
                    {field(
                      "slug",
                      english
                        ? "URL key (English letters)"
                        : "شناسهٔ لینک (حروف انگلیسی)"
                    )}
                    <label className="admin-field">
                      <span>{english ? "Category" : "دسته‌بندی"}</span>
                      <select
                        value={form.category}
                        onChange={event =>
                          change("category", event.target.value)
                        }
                      >
                        <option value="thermos">
                          {english ? "Thermos flask" : "فلاسک"}
                        </option>
                        <option value="tea">
                          {english ? "Tea flask" : "چای‌دم"}
                        </option>
                        <option value="travel">
                          {english ? "Travel cup" : "پیالهٔ سفری"}
                        </option>
                      </select>
                    </label>
                  </div>
                  <div className="admin-form-grid">
                    {field(
                      "nameFa",
                      english ? "Product name (Dari)" : "نام کالا (دری)"
                    )}
                    {field(
                      "nameEn",
                      english ? "Product name (English)" : "نام کالا (انگلیسی)"
                    )}
                  </div>
                  <div className="admin-form-grid">
                    {field(
                      "descriptionFa",
                      english ? "Description (Dari)" : "توضیح (دری)"
                    )}
                    {field(
                      "descriptionEn",
                      english ? "Description (English)" : "توضیح (انگلیسی)"
                    )}
                  </div>
                  <div className="form-section-label">
                    <span>02</span>
                    {english ? "Product details" : "جزئیات کالا"}
                  </div>
                  <div className="admin-form-grid">
                    {field(
                      "brandFa",
                      english ? "Brand / maker (Dari)" : "برند / سازنده (دری)"
                    )}
                    {field(
                      "brandEn",
                      english
                        ? "Brand / maker (English)"
                        : "برند / سازنده (انگلیسی)"
                    )}
                    {field(
                      "originFa",
                      english ? "Country of origin (Dari)" : "کشور سازنده (دری)"
                    )}
                    {field(
                      "originEn",
                      english
                        ? "Country of origin (English)"
                        : "کشور سازنده (انگلیسی)"
                    )}
                    {field(
                      "capacityMl",
                      english ? "Capacity (ml)" : "حجم (ml)",
                      "number"
                    )}
                    {field(
                      "price",
                      english ? "Sample price (AFN)" : "قیمت نمونه (AFN)",
                      "number"
                    )}
                    {field("stock", english ? "Stock" : "موجودی", "number")}
                    {field(
                      "dimensionsFa",
                      english ? "Dimensions (Dari)" : "ابعاد (دری)"
                    )}
                    {field(
                      "dimensionsEn",
                      english ? "Dimensions (English)" : "ابعاد (انگلیسی)"
                    )}
                    {field(
                      "materialFa",
                      english ? "Material (Dari)" : "جنس (دری)"
                    )}
                    {field(
                      "materialEn",
                      english ? "Material (English)" : "جنس (انگلیسی)"
                    )}
                    {field(
                      "insulationFa",
                      english ? "Insulation (Dari)" : "عملکرد عایق (دری)"
                    )}
                    {field(
                      "insulationEn",
                      english ? "Insulation (English)" : "عملکرد عایق (انگلیسی)"
                    )}
                    {field(
                      "colorsFa",
                      english ? "Colours (Dari)" : "رنگ‌ها (دری)"
                    )}
                    {field(
                      "colorsEn",
                      english ? "Colours (English)" : "رنگ‌ها (انگلیسی)"
                    )}
                  </div>
                  <div className="product-photo-editor">
                    <label className="admin-field">
                      <span>{english ? "Product photo" : "تصویر کالا"}</span>
                      <div className="image-upload-input">
                        <ImagePlus size={18} />
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp"
                          multiple
                          onChange={event => {
                            const files = Array.from(
                              event.currentTarget.files ?? []
                            );
                            event.currentTarget.value = "";
                            void handleImages(files);
                          }}
                          aria-label={
                            english
                              ? "Upload product photos"
                              : "بارگذاری عکس‌های کالا"
                          }
                        />
                        <small>
                          {uploadImage.isPending
                            ? english
                              ? "Uploading…"
                              : "در حال بارگذاری…"
                            : english
                              ? `PNG, JPG or WebP · up to 8 photos · 5 MB each (${form.galleryUrls?.length ?? 0}/8)`
                              : `PNG، JPG یا WebP · حداکثر ۸ عکس، هر عکس ۵ مگابایت (${form.galleryUrls?.length ?? 0}/۸)`}
                        </small>
                      </div>
                    </label>
                  </div>
                  {(form.galleryUrls ?? []).length > 0 && (
                    <div className="admin-photo-grid">
                      {(form.galleryUrls ?? []).map((image, index) => (
                        <div className="admin-photo-card" key={image}>
                          <img
                            src={image}
                            alt={`${form.nameEn || "Product"} view ${index + 1}`}
                          />
                          <small>
                            {index === 0
                              ? english
                                ? "Main photo"
                                : "عکس اصلی"
                              : english
                                ? `View ${index + 1}`
                                : `نمای ${index + 1}`}
                          </small>
                          <div>
                            {index > 0 && (
                              <button
                                type="button"
                                title={
                                  english
                                    ? "Set as main photo"
                                    : "انتخاب به‌عنوان عکس اصلی"
                                }
                                onClick={() =>
                                  setForm(old => ({
                                    ...old,
                                    imageUrl: image,
                                    galleryUrls: [
                                      image,
                                      ...(old.galleryUrls ?? []).filter(
                                        item => item !== image
                                      ),
                                    ],
                                  }))
                                }
                              >
                                <Check size={14} />
                              </button>
                            )}
                            <button
                              type="button"
                              title={english ? "Remove photo" : "حذف عکس"}
                              aria-label={`${english ? "Remove photo" : "حذف عکس"} ${index + 1}`}
                              onClick={() =>
                                setForm(old => {
                                  const galleryUrls = (
                                    old.galleryUrls ?? []
                                  ).filter(item => item !== image);
                                  return {
                                    ...old,
                                    galleryUrls,
                                    imageUrl:
                                      old.imageUrl === image
                                        ? (galleryUrls[0] ?? "")
                                        : old.imageUrl,
                                  };
                                })
                              }
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="admin-check-row">
                    <label>
                      <input
                        type="checkbox"
                        checked={form.featured}
                        onChange={event =>
                          change("featured", event.target.checked)
                        }
                      />
                      {english
                        ? "Feature on home page"
                        : "نمایش در انتخاب‌های خانه"}
                    </label>
                    <label>
                      <input
                        type="checkbox"
                        checked={form.isDemo}
                        onChange={event =>
                          change("isDemo", event.target.checked)
                        }
                      />
                      {english
                        ? "Sample/demo listing (keep checked until verified)"
                        : "کالای نمونه است (تا تأیید واقعی تیک بماند)"}
                    </label>
                  </div>
                  <button
                    className="button button-green full-button"
                    type="submit"
                    disabled={saveProduct.isPending || uploadImage.isPending}
                  >
                    <Save size={17} />
                    {saveProduct.isPending
                      ? english
                        ? "Saving…"
                        : "در حال ذخیره…"
                      : editing
                        ? english
                          ? "Save changes"
                          : "ذخیرهٔ تغییرات"
                        : english
                          ? "Add product"
                          : "افزودن کالا"}
                  </button>
                </form>
              </section>
            </div>
          )}
          {tab === "orders" && (
            <section className="admin-panel">
              <div className="panel-head">
                <div>
                  <span className="eyebrow">
                    {english ? "ORDER INBOX" : "صندوق سفارش‌ها"}
                  </span>
                  <h2>{english ? "Recent orders" : "سفارش‌های تازه"}</h2>
                </div>
                <button
                  className="admin-refresh"
                  onClick={() => void orders.refetch()}
                >
                  {english ? "Refresh" : "تازه‌سازی"}
                </button>
              </div>
              {orders.isLoading ? (
                <div className="admin-empty">
                  {english ? "Loading orders…" : "در حال بارگیری…"}
                </div>
              ) : orders.error ? (
                <div className="admin-empty">
                  {english
                    ? "Order records are unavailable."
                    : "سفارش‌ها در دسترس نیستند."}
                </div>
              ) : ordersList.length === 0 ? (
                <div className="admin-empty">
                  <ClipboardList size={34} />
                  <strong>
                    {english ? "No orders yet" : "هنوز سفارشی نیست"}
                  </strong>
                  <span>
                    {english
                      ? "Customer orders will appear here."
                      : "سفارش مشتری در این‌جا نمایش داده می‌شود."}
                  </span>
                </div>
              ) : (
                <div className="admin-table-wrap">
                  <table className="admin-table order-table">
                    <thead>
                      <tr>
                        <th>{english ? "Order" : "سفارش"}</th>
                        <th>{english ? "Customer" : "مشتری"}</th>
                        <th>{english ? "Address" : "نشانی"}</th>
                        <th>{english ? "Items / total" : "کالاها / جمع"}</th>
                        <th>{english ? "Status" : "وضعیت"}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ordersList.map(order => (
                        <tr key={order.orderCode}>
                          <td>
                            <strong>{order.orderCode}</strong>
                            <small>
                              {new Date(order.createdAt).toLocaleDateString(
                                english ? "en-AF" : "fa-AF"
                              )}
                            </small>
                          </td>
                          <td>
                            <strong>{order.customerName}</strong>
                            <a href={`tel:${order.phone}`}>{order.phone}</a>
                          </td>
                          <td>
                            {order.province}, {order.city}
                            <small>{order.address}</small>
                          </td>
                          <td>
                            <strong>{money(order.total, locale)}</strong>
                            <small>
                              {order.items
                                .map(
                                  item =>
                                    `${english ? item.nameEn : item.nameFa}${item.colorEn ? ` · ${english ? item.colorEn : item.colorFa}` : ""} × ${item.quantity}`
                                )
                                .join(" · ")}
                            </small>
                          </td>
                          <td>
                            <label className="status-select">
                              <span
                                className={`status-dot status-${order.status}`}
                              />
                              <select
                                value={order.status}
                                disabled={order.status === "cancelled"}
                                onChange={event =>
                                  updateOrder.mutate({
                                    orderCode: order.orderCode,
                                    status: event.target.value as OrderStatus,
                                  })
                                }
                              >
                                {statuses.map(status => (
                                  <option key={status} value={status}>
                                    {statusText(status, english)}
                                  </option>
                                ))}
                              </select>
                              <ChevronDown size={13} />
                            </label>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          )}
          {tab === "settings" && (
            <section className="admin-panel settings-panel">
              <div className="panel-head">
                <div>
                  <span className="eyebrow">
                    {english ? "CONTACT & IDENTITY" : "هویت و تماس"}
                  </span>
                  <h2>{english ? "Your shop" : "فروشگاه شما"}</h2>
                  <p>
                    {english
                      ? "A WhatsApp number is not pre-filled; customers should never be sent to the wrong shop."
                      : "شمارهٔ واتس‌اپ از پیش پر نشده تا مشتری به شمارهٔ نادرست نرود."}
                  </p>
                </div>
              </div>
              <form
                className="settings-edit-form"
                onSubmit={event => {
                  event.preventDefault();
                  saveSettings.mutate(settingsForm);
                }}
              >
                <div className="admin-form-grid">
                  {(
                    [
                      ["storeNameFa", "نام فروشگاه (دری)"],
                      ["storeNameEn", "Shop name (English)"],
                      [
                        "whatsappNumber",
                        "شمارهٔ واتس‌اپ با کود کشور (مثلاً +937...)",
                      ],
                      ["noticeFa", "پیام پس از خرید (دری)"],
                      ["noticeEn", "Post-order note (English)"],
                    ] as const
                  ).map(([key, label]) => (
                    <label className="admin-field" key={key}>
                      <span>{label}</span>
                      <input
                        value={settingsForm[key]}
                        required={key !== "whatsappNumber"}
                        onChange={event =>
                          setSettingsForm(old => ({
                            ...old,
                            [key]: event.target.value,
                          }))
                        }
                        placeholder={
                          key === "whatsappNumber" ? "+93 70 000 0000" : ""
                        }
                      />
                    </label>
                  ))}
                </div>
                <div className="whatsapp-preview">
                  <MessageCircleIcon />
                  <div>
                    <b>
                      {english
                        ? "WhatsApp direct order"
                        : "سفارش مستقیم واتس‌اپ"}
                    </b>
                    <span>
                      {settingsForm.whatsappNumber ||
                        (english
                          ? "No number set — the link stays hidden on the shop."
                          : "شماره تعیین نشده؛ پیوند در فروشگاه پنهان می‌ماند.")}
                    </span>
                  </div>
                </div>
                <button
                  className="button button-green"
                  type="submit"
                  disabled={saveSettings.isPending}
                >
                  <Save size={17} />
                  {english ? "Save shop details" : "ذخیرهٔ تنظیمات فروشگاه"}
                </button>
              </form>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}

function LockIcon() {
  return <CircleAlert size={23} />;
}
function MessageCircleIcon() {
  return <ShoppingBag size={20} />;
}
