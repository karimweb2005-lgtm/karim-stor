import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

type CartLine = { slug: string; color: string; quantity: number };
type Cart = {
  lines: CartLine[];
  isOpen: boolean;
  open: () => void;
  close: () => void;
  add: (slug: string, color?: string) => void;
  setQuantity: (slug: string, color: string, quantity: number) => void;
  remove: (slug: string, color: string) => void;
  clear: () => void;
  count: number;
};
const Context = createContext<Cart | null>(null);

function restoreCart(): CartLine[] {
  try {
    const saved = JSON.parse(localStorage.getItem("thermora-cart") || "[]");
    if (!Array.isArray(saved)) return [];
    return saved
      .filter(
        (line): line is { slug: string; quantity: number; color?: string } =>
          line &&
          typeof line.slug === "string" &&
          Number.isInteger(line.quantity) &&
          line.quantity > 0
      )
      .map(line => ({
        slug: line.slug,
        quantity: Math.min(20, line.quantity),
        color: typeof line.color === "string" ? line.color : "",
      }));
  } catch {
    return [];
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>(restoreCart);
  const [isOpen, setIsOpen] = useState(false);
  useEffect(() => {
    try {
      localStorage.setItem("thermora-cart", JSON.stringify(lines));
    } catch {}
  }, [lines]);
  const value = useMemo<Cart>(
    () => ({
      lines,
      isOpen,
      open: () => setIsOpen(true),
      close: () => setIsOpen(false),
      add: (slug, color = "") =>
        setLines(old => {
          const picked = color.trim();
          const found = old.find(
            line => line.slug === slug && line.color === picked
          );
          return found
            ? old.map(line =>
                line.slug === slug && line.color === picked
                  ? { ...line, quantity: Math.min(20, line.quantity + 1) }
                  : line
              )
            : [...old, { slug, color: picked, quantity: 1 }];
        }),
      setQuantity: (slug, color, quantity) =>
        setLines(old =>
          quantity < 1
            ? old.filter(line => line.slug !== slug || line.color !== color)
            : old.map(line =>
                line.slug === slug && line.color === color
                  ? { ...line, quantity: Math.min(20, quantity) }
                  : line
              )
        ),
      remove: (slug, color) =>
        setLines(old =>
          old.filter(line => line.slug !== slug || line.color !== color)
        ),
      clear: () => setLines([]),
      count: lines.reduce((sum, line) => sum + line.quantity, 0),
    }),
    [lines, isOpen]
  );
  return <Context.Provider value={value}>{children}</Context.Provider>;
}

export function useCart() {
  const value = useContext(Context);
  if (!value) throw new Error("useCart must be used within CartProvider");
  return value;
}
