import { ArrowUpRight, Globe2, Menu, Search, ShoppingBag, X } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { useCart } from "@/contexts/CartContext";
import { useLocale } from "@/lib/i18n";
import { CartDrawer } from "./CartDrawer";

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return <Link href="/" className={`brand-lockup ${compact ? "brand-compact" : ""}`} aria-label="Kareem Store — خانه">
    <span className="brand-symbol" aria-hidden="true"><svg viewBox="0 0 44 44" fill="none"><circle cx="22" cy="22" r="19" stroke="currentColor" strokeWidth="1.25"/><path d="M16 29h12M18 26c-3-5 6-6 2-12M23 25c-2-4 6-6 3-11M16 21c0-2 1-4 3-6" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round"/><path d="M15 31h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg></span>
    {!compact && <span className="brand-copy"><strong>Kareem Store</strong><small>KAREEM STORE · KABUL</small></span>}
  </Link>;
}

export function StoreHeader() {
  const { locale, setLocale, t } = useLocale();
  const cart = useCart();
  const [menu, setMenu] = useState(false);
  const focusSearch = () => { setMenu(false); window.location.href = "/#products"; window.setTimeout(() => window.dispatchEvent(new Event("thermora-search-focus")), 300); };
  return <>
    <div className="notice-bar"><span className="notice-dot" />{t.shopNotice}<span className="notice-side">{locale === "fa" ? "ساخته برای روزهای واقعی" : "Made for everyday rituals"}</span></div>
    <header className="store-header">
      <div className="header-inner">
        <button className="icon-btn mobile-menu-toggle" onClick={() => setMenu(!menu)} aria-label={menu ? "بستن فهرست" : "بازکردن فهرست"}>{menu ? <X /> : <Menu />}</button>
        <BrandMark />
        <nav className={`main-nav ${menu ? "nav-open" : ""}`} aria-label={locale === "fa" ? "فهرست اصلی" : "Main navigation"}>
          <a href="/#products" onClick={() => setMenu(false)}>{t.shop}</a><a href="/#story" onClick={() => setMenu(false)}>{t.story}</a><a href="/#faq" onClick={() => setMenu(false)}>{t.faq}</a>
        </nav>
        <div className="header-actions">
          <button className="icon-btn search-toggle" onClick={focusSearch} aria-label={t.search}><Search /></button>
          <button className="language-toggle" onClick={() => setLocale(locale === "fa" ? "en" : "fa")} aria-label="Change language"><Globe2 size={15} /><span>{locale === "fa" ? "EN" : "دری"}</span></button>
          <button className="cart-trigger" onClick={cart.open}><ShoppingBag size={18} /><span>{t.cart}</span><b>{cart.count}</b><ArrowUpRight className="cart-arrow" size={14} /></button>
        </div>
      </div>
    </header>
    <CartDrawer />
  </>;
}
