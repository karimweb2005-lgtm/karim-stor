import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import { DEFAULT_SETTINGS } from "../shared/products";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createGuestOrder,
  getProduct,
  getStoreSettings,
  listBestSellers,
  listOrders,
  listProducts,
  removeProduct,
  saveStoreSettings,
  updateOrderStatus,
  upsertProduct,
} from "./db";
import { storagePut } from "./storage";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";

const isProjectStoragePath = (path: string) =>
  path.startsWith("/manus-storage/") &&
  !/[?#\\\s]/.test(path) &&
  !path.split("/").some(segment => segment === "." || segment === "..");
const isProductImagePath = (path: string) =>
  isProjectStoragePath(path) ||
  /^\/images\/products\/[A-Za-z0-9][A-Za-z0-9._-]*\.webp$/.test(path);

const productInput = z
  .object({
    slug: z
      .string()
      .trim()
      .min(2)
      .max(100)
      .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
    nameFa: z.string().trim().min(1).max(180),
    nameEn: z.string().trim().min(1).max(180),
    descriptionFa: z.string().trim().min(1).max(5000),
    descriptionEn: z.string().trim().min(1).max(5000),
    brandFa: z.string().trim().min(1).max(180),
    brandEn: z.string().trim().min(1).max(180),
    originFa: z.string().trim().min(1).max(180),
    originEn: z.string().trim().min(1).max(180),
    capacityMl: z.number().int().min(1).max(100000),
    dimensionsFa: z.string().trim().min(1).max(180),
    dimensionsEn: z.string().trim().min(1).max(180),
    materialFa: z.string().trim().min(1).max(180),
    materialEn: z.string().trim().min(1).max(180),
    insulationFa: z.string().trim().min(1).max(180),
    insulationEn: z.string().trim().min(1).max(180),
    colorsFa: z.string().trim().min(1).max(500),
    colorsEn: z.string().trim().min(1).max(500),
    price: z.number().int().min(0).max(100000000),
    stock: z.number().int().min(0).max(10000000),
    imageUrl: z
      .string()
      .trim()
      .min(1)
      .max(2048)
      .refine(
        isProductImagePath,
        "Choose a bundled product photo or upload one to store storage."
      ),
    galleryUrls: z
      .array(
        z
          .string()
          .trim()
          .min(1)
          .max(2048)
          .refine(
            isProductImagePath,
            "Choose a bundled product photo or upload one to store storage."
          )
      )
      .min(1)
      .max(8)
      .refine(urls => new Set(urls).size === urls.length),
    category: z.enum(["thermos", "tea", "travel"]),
    featured: z.boolean(),
    isDemo: z.boolean(),
  })
  .superRefine((product, context) => {
    if (product.galleryUrls[0] !== product.imageUrl) {
      context.addIssue({
        code: "custom",
        path: ["imageUrl"],
        message: "The primary photo must be the first gallery image.",
      });
    }
  });

const settingsInput = z.object({
  storeNameFa: z.string().trim().min(1).max(180),
  storeNameEn: z.string().trim().min(1).max(180),
  whatsappNumber: z
    .string()
    .trim()
    .max(40)
    .regex(/^[+0-9()\s-]*$/),
  noticeFa: z.string().trim().max(1000),
  noticeEn: z.string().trim().max(1000),
});

const customerInput = z.object({
  customerName: z.string().trim().min(2).max(180),
  phone: z
    .string()
    .trim()
    .min(8)
    .max(40)
    .regex(/^[+0-9()\s-]+$/),
  province: z.string().trim().min(2).max(120),
  city: z.string().trim().min(2).max(120),
  address: z.string().trim().min(4).max(1500),
  note: z.string().trim().max(1500).default(""),
  lines: z
    .array(
      z.object({
        slug: z.string().min(2).max(100),
        color: z.string().trim().max(100).default(""),
        quantity: z.number().int().min(1).max(20),
      })
    )
    .min(1)
    .max(30),
});

function publicError(error: unknown): never {
  if (error instanceof Error && error.message.startsWith("INSUFFICIENT:")) {
    throw new TRPCError({
      code: "CONFLICT",
      message:
        "Some items no longer have enough stock. Please review your cart.",
    });
  }
  if (error instanceof Error && error.message.startsWith("INVALID_COLOR:")) {
    throw new TRPCError({
      code: "CONFLICT",
      message:
        "That colour is no longer available. Please refresh the product.",
    });
  }
  throw error;
}

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  store: router({
    products: publicProcedure.query(() => listProducts()),
    bestSellers: publicProcedure.query(() => listBestSellers()),
    product: publicProcedure
      .input(z.object({ slug: z.string().min(1).max(100) }))
      .query(({ input }) => getProduct(input.slug)),
    settings: publicProcedure.query(() => getStoreSettings()),
    placeOrder: publicProcedure
      .input(customerInput)
      .mutation(async ({ input }) => {
        try {
          const result = await createGuestOrder({
            ...input,
            orderCode: `TR-${Date.now().toString(36).toUpperCase()}-${nanoid(5).toUpperCase()}`,
          });
          return {
            ...result,
            message:
              "Order received; the shop will confirm delivery and payment.",
          };
        } catch (error) {
          return publicError(error);
        }
      }),
    admin: router({
      products: adminProcedure.query(() => listProducts()),
      orders: adminProcedure.query(() => listOrders()),
      settings: adminProcedure.query(() => getStoreSettings()),
      saveProduct: adminProcedure
        .input(productInput)
        .mutation(({ input }) => upsertProduct(input)),
      removeProduct: adminProcedure
        .input(z.object({ slug: z.string().min(1).max(100) }))
        .mutation(({ input }) => removeProduct(input.slug)),
      updateOrder: adminProcedure
        .input(
          z.object({
            orderCode: z.string().min(4).max(32),
            status: z.enum([
              "new",
              "confirmed",
              "shipped",
              "completed",
              "cancelled",
            ]),
          })
        )
        .mutation(({ input }) =>
          updateOrderStatus(input.orderCode, input.status)
        ),
      saveSettings: adminProcedure
        .input(settingsInput)
        .mutation(({ input }) => saveStoreSettings(input)),
      uploadImage: adminProcedure
        .input(
          z.object({
            filename: z.string().max(180),
            mime: z.enum(["image/png", "image/jpeg", "image/webp"]),
            base64: z.string().min(1).max(8_000_000),
          })
        )
        .mutation(async ({ input }) => {
          const data = Buffer.from(input.base64, "base64");
          if (!data.length || data.length > 5 * 1024 * 1024)
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "Image must be smaller than 5 MB.",
            });
          const signatures: Record<string, boolean> = {
            "image/png":
              data[0] === 0x89 &&
              data[1] === 0x50 &&
              data[2] === 0x4e &&
              data[3] === 0x47,
            "image/jpeg":
              data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff,
            "image/webp":
              data.toString("ascii", 0, 4) === "RIFF" &&
              data.toString("ascii", 8, 12) === "WEBP",
          };
          if (!signatures[input.mime])
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "Image file type did not match its contents.",
            });
          const extension =
            input.mime === "image/jpeg" ? "jpg" : input.mime.split("/")[1];
          const uploaded = await storagePut(
            `thermora/products/${nanoid(12)}.${extension}`,
            data,
            input.mime
          );
          return { imageUrl: uploaded.url };
        }),
    }),
  }),
});

export type AppRouter = typeof appRouter;
