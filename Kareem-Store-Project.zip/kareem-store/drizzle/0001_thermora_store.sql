CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderCode` varchar(32) NOT NULL,
	`customerName` varchar(180) NOT NULL,
	`phone` varchar(40) NOT NULL,
	`province` varchar(120) NOT NULL,
	`city` varchar(120) NOT NULL,
	`address` text NOT NULL,
	`note` text,
	`items` json NOT NULL,
	`total` int NOT NULL,
	`status` enum('new','confirmed','shipped','completed','cancelled') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderCode_unique` UNIQUE(`orderCode`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`slug` varchar(100) NOT NULL,
	`nameFa` varchar(180) NOT NULL,
	`nameEn` varchar(180) NOT NULL,
	`descriptionFa` text NOT NULL,
	`descriptionEn` text NOT NULL,
	`brandFa` varchar(180) NOT NULL,
	`brandEn` varchar(180) NOT NULL,
	`originFa` varchar(180) NOT NULL,
	`originEn` varchar(180) NOT NULL,
	`capacityMl` int NOT NULL,
	`dimensionsFa` varchar(180) NOT NULL,
	`dimensionsEn` varchar(180) NOT NULL,
	`materialFa` varchar(180) NOT NULL,
	`materialEn` varchar(180) NOT NULL,
	`insulationFa` varchar(180) NOT NULL,
	`insulationEn` varchar(180) NOT NULL,
	`colorsFa` varchar(500) NOT NULL,
	`colorsEn` varchar(500) NOT NULL,
	`price` int NOT NULL,
	`stock` int NOT NULL DEFAULT 0,
	`imageUrl` varchar(2048) NOT NULL,
	`category` enum('thermos','tea','travel') NOT NULL DEFAULT 'thermos',
	`featured` boolean NOT NULL DEFAULT false,
	`isDemo` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_slug` PRIMARY KEY(`slug`)
);
--> statement-breakpoint
CREATE TABLE `storeSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storeNameFa` varchar(180) NOT NULL,
	`storeNameEn` varchar(180) NOT NULL,
	`whatsappNumber` varchar(40) NOT NULL DEFAULT '',
	`noticeFa` text NOT NULL,
	`noticeEn` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `storeSettings_id` PRIMARY KEY(`id`)
);
