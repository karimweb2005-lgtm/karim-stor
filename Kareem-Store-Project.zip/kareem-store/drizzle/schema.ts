import {
  boolean,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/** User roles are assigned server-side; storefront customers never need an account. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const products = mysqlTable("products", {
  slug: varchar("slug", { length: 100 }).primaryKey(),
  nameFa: varchar("nameFa", { length: 180 }).notNull(),
  nameEn: varchar("nameEn", { length: 180 }).notNull(),
  descriptionFa: text("descriptionFa").notNull(),
  descriptionEn: text("descriptionEn").notNull(),
  brandFa: varchar("brandFa", { length: 180 }).notNull(),
  brandEn: varchar("brandEn", { length: 180 }).notNull(),
  originFa: varchar("originFa", { length: 180 }).notNull(),
  originEn: varchar("originEn", { length: 180 }).notNull(),
  capacityMl: int("capacityMl").notNull(),
  dimensionsFa: varchar("dimensionsFa", { length: 180 }).notNull(),
  dimensionsEn: varchar("dimensionsEn", { length: 180 }).notNull(),
  materialFa: varchar("materialFa", { length: 180 }).notNull(),
  materialEn: varchar("materialEn", { length: 180 }).notNull(),
  insulationFa: varchar("insulationFa", { length: 180 }).notNull(),
  insulationEn: varchar("insulationEn", { length: 180 }).notNull(),
  colorsFa: varchar("colorsFa", { length: 500 }).notNull(),
  colorsEn: varchar("colorsEn", { length: 500 }).notNull(),
  price: int("price").notNull(),
  stock: int("stock").default(0).notNull(),
  imageUrl: varchar("imageUrl", { length: 2048 }).notNull(),
  galleryUrls: json("galleryUrls").$type<string[]>(),
  category: mysqlEnum("category", ["thermos", "tea", "travel"])
    .default("thermos")
    .notNull(),
  featured: boolean("featured").default(false).notNull(),
  isDemo: boolean("isDemo").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OrderLine = {
  slug: string;
  nameFa: string;
  nameEn: string;
  colorFa: string;
  colorEn: string;
  imageUrl: string;
  quantity: number;
  unitPrice: number;
};
export type OrderStatus =
  | "new"
  | "confirmed"
  | "shipped"
  | "completed"
  | "cancelled";

export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderCode: varchar("orderCode", { length: 32 }).notNull().unique(),
  customerName: varchar("customerName", { length: 180 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  province: varchar("province", { length: 120 }).notNull(),
  city: varchar("city", { length: 120 }).notNull(),
  address: text("address").notNull(),
  note: text("note"),
  items: json("items").$type<OrderLine[]>().notNull(),
  total: int("total").notNull(),
  status: mysqlEnum("status", [
    "new",
    "confirmed",
    "shipped",
    "completed",
    "cancelled",
  ])
    .default("new")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** One settings row (id=1) per shop; the WhatsApp number is intentionally unset at first. */
export const storeSettings = mysqlTable("storeSettings", {
  id: int("id").autoincrement().primaryKey(),
  storeNameFa: varchar("storeNameFa", { length: 180 }).notNull(),
  storeNameEn: varchar("storeNameEn", { length: 180 }).notNull(),
  whatsappNumber: varchar("whatsappNumber", { length: 40 })
    .default("")
    .notNull(),
  noticeFa: text("noticeFa").notNull(),
  noticeEn: text("noticeEn").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Product = typeof products.$inferSelect;
export type StoreOrder = typeof orders.$inferSelect;
export type StoreSettingsRow = typeof storeSettings.$inferSelect;
