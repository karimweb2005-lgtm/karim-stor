import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { DEFAULT_SETTINGS, DEMO_PRODUCTS } from "../shared/products";
import {
  InsertUser,
  OrderLine,
  OrderStatus,
  orders,
  products,
  storeSettings,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Connection setup failed:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (ENV.ownerOpenId && user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db
    .insert(users)
    .values(values)
    .onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result[0];
}

export async function listProducts() {
  const db = await getDb();
  if (!db) return DEMO_PRODUCTS;
  const result = await db
    .select()
    .from(products)
    .orderBy(desc(products.featured), products.nameFa);
  return result;
}

export async function listBestSellers(limit = 4) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({ items: orders.items, status: orders.status })
    .from(orders);
  const quantityBySlug = new Map<string, number>();
  for (const order of rows) {
    if (
      !(["confirmed", "shipped", "completed"] as OrderStatus[]).includes(
        order.status
      )
    )
      continue;
    for (const item of order.items ?? []) {
      quantityBySlug.set(
        item.slug,
        (quantityBySlug.get(item.slug) ?? 0) + item.quantity
      );
    }
  }
  return [...quantityBySlug.entries()]
    .sort((left, right) => right[1] - left[1])
    .slice(0, Math.max(0, Math.min(limit, 12)))
    .map(([slug, sold]) => ({ slug, sold }));
}

export async function getProduct(slug: string) {
  const db = await getDb();
  if (!db) return DEMO_PRODUCTS.find(item => item.slug === slug) ?? null;
  const result = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1);
  return result[0] ?? null;
}

export async function upsertProduct(input: typeof products.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ slug: products.slug })
    .from(products)
    .where(eq(products.slug, input.slug))
    .limit(1);
  if (existing.length) {
    await db
      .update(products)
      .set({ ...input, updatedAt: new Date() })
      .where(eq(products.slug, input.slug));
  } else {
    await db.insert(products).values(input);
  }
  const result = await db
    .select()
    .from(products)
    .where(eq(products.slug, input.slug))
    .limit(1);
  return result[0];
}

export async function removeProduct(slug: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(products).where(eq(products.slug, slug));
  return { success: true };
}

export async function getStoreSettings() {
  const db = await getDb();
  if (!db) return { ...DEFAULT_SETTINGS };
  const result = await db.select().from(storeSettings).limit(1);
  return result[0] ?? { id: 1, ...DEFAULT_SETTINGS, updatedAt: new Date() };
}

export async function updateStoreSettings(
  input: typeof storeSettings.$inferInsert
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values = { ...DEFAULT_SETTINGS, ...input, id: 1 };
  await db
    .insert(storeSettings)
    .values(values)
    .onDuplicateKeyUpdate({ set: { ...values, updatedAt: new Date() } });
  return getStoreSettings();
}

export async function createGuestOrder(input: {
  orderCode: string;
  customerName: string;
  phone: string;
  province: string;
  city: string;
  address: string;
  note: string;
  lines: { slug: string; color: string; quantity: number }[];
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    const orderLines: OrderLine[] = [];
    let total = 0;
    for (const requested of input.lines) {
      const found = await tx
        .select()
        .from(products)
        .where(eq(products.slug, requested.slug))
        .limit(1)
        .for("update");
      const product = found[0];
      if (!product || product.stock < requested.quantity)
        throw new Error(`INSUFFICIENT:${requested.slug}`);
      const colorsEn = product.colorsEn
        .split(/[،,]/)
        .map(color => color.trim());
      const colorsFa = product.colorsFa
        .split(/[،,]/)
        .map(color => color.trim());
      const colorIndex = requested.color
        ? colorsEn.indexOf(requested.color)
        : 0;
      if (colorIndex < 0) throw new Error(`INVALID_COLOR:${requested.slug}`);
      orderLines.push({
        slug: product.slug,
        nameFa: product.nameFa,
        nameEn: product.nameEn,
        colorFa: colorsFa[colorIndex] ?? "",
        colorEn: colorsEn[colorIndex] ?? "",
        imageUrl: product.imageUrl,
        quantity: requested.quantity,
        unitPrice: product.price,
      });
      total += product.price * requested.quantity;
      await tx
        .update(products)
        .set({
          stock: sql`${products.stock} - ${requested.quantity}`,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(products.slug, product.slug),
            sql`${products.stock} >= ${requested.quantity}`
          )
        );
    }
    await tx.insert(orders).values({
      orderCode: input.orderCode,
      customerName: input.customerName,
      phone: input.phone,
      province: input.province,
      city: input.city,
      address: input.address,
      note: input.note,
      items: orderLines,
      total,
      status: "new",
    });
    return { orderCode: input.orderCode, total, items: orderLines };
  });
}

export async function listOrders() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(300);
}

export async function updateOrderStatus(
  orderCode: string,
  status: OrderStatus
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    const found = await tx
      .select()
      .from(orders)
      .where(eq(orders.orderCode, orderCode))
      .limit(1)
      .for("update");
    const current = found[0];
    if (!current) throw new Error("ORDER_NOT_FOUND");
    if (status === "cancelled" && current.status !== "cancelled") {
      for (const item of current.items) {
        await tx
          .update(products)
          .set({ stock: sql`${products.stock} + ${item.quantity}` })
          .where(eq(products.slug, item.slug));
      }
    }
    if (current.status === "cancelled" && status !== "cancelled")
      throw new Error("CANCELLED_ORDER_CANNOT_BE_REOPENED");
    await tx
      .update(orders)
      .set({ status, updatedAt: new Date() })
      .where(eq(orders.orderCode, orderCode));
    return { success: true };
  });
}

export async function saveStoreSettings(input: {
  storeNameFa: string;
  storeNameEn: string;
  whatsappNumber: string;
  noticeFa: string;
  noticeEn: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const existing = await db
    .select({ id: storeSettings.id })
    .from(storeSettings)
    .limit(1);
  if (existing.length)
    await db
      .update(storeSettings)
      .set({ ...input, updatedAt: new Date() })
      .where(eq(storeSettings.id, existing[0].id));
  else await db.insert(storeSettings).values({ ...DEFAULT_SETTINGS, ...input });
  return getStoreSettings();
}

/** Seed sample records only into a genuinely empty catalog; never reset shop edits on restart. */
export async function ensureDemoData() {
  const db = await getDb();
  if (!db) return;
  const existing = await db
    .select({ slug: products.slug })
    .from(products)
    .limit(1);
  if (!existing.length) {
    try {
      await db.insert(products).values(DEMO_PRODUCTS);
    } catch (error) {
      const afterRace = await db
        .select({ slug: products.slug })
        .from(products)
        .limit(1);
      if (!afterRace.length) throw error;
    }
  }
  const settings = await db
    .select({ id: storeSettings.id })
    .from(storeSettings)
    .limit(1);
  if (!settings.length)
    await db.insert(storeSettings).values({ ...DEFAULT_SETTINGS });
}
