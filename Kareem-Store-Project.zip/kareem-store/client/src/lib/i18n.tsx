import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

type Locale = "fa" | "en";
const words = {
  fa: {
    shop: "فروشگاه",
    story: "چرا کریم ستور؟",
    faq: "پرسش‌ها",
    search: "جست‌وجوی فلاسک و چای‌دم",
    all: "همه",
    thermos: "فلاسک",
    tea: "چای‌دم",
    travel: "همراه سفر",
    heroEyebrow: "چایِ خوب، هم‌سفرِ هر روز",
    heroTitle: "برای راه و روزهای آرام.",
    heroBody:
      "فلاسکی را پیدا کن که روزت را ساده‌تر می‌کند. بی‌حساب کاربری؛ با ثبت سفارش ساده و گفت‌وگوی مستقیم با فروشگاه.",
    browse: "دیدن محصولات",
    whatsapp: "سفارش از واتس‌اپ",
    newLabel: "انتخاب‌های امروز",
    collectionTitle: "همراه لحظه‌های تو",
    collectionBody:
      "از چای صبح تا راهِ خانه؛ گزینه‌ها را ببین، انتخاب کن و به‌آسانی سفارش بده.",
    featured: "انتخاب‌های کریم ستور",
    seeAll: "دیدن همه",
    add: "افزودن به سبد",
    details: "جزئیات",
    demo: "اطلاعات و قیمت نمونه · پیش از فروش تأیید شود",
    sample: "دمو",
    capacity: "حجم",
    origin: "کشور سازنده",
    dimensions: "ابعاد",
    material: "جنس",
    insulation: "عملکرد عایق",
    colors: "رنگ‌ها",
    brand: "برند / سازنده",
    stock: "موجودی نمونه",
    stockOut: "ناموجود",
    benefits: "خریدی ساده، از هر جا",
    benefit1: "بدون حساب کاربری",
    benefit1Text: "محصول را پیدا کن، اطلاعات تماس را بنویس و تمام.",
    benefit2: "قیمت روشن",
    benefit2Text: "قیمت هر قلم و جمع سفارش را پیش از ثبت ببین.",
    benefit3: "تماس مستقیم",
    benefit3Text: "برای هماهنگی سفارش، مستقیم با فروشگاه حرف بزن.",
    testimonial: "نظر خریداران",
    testimonialNote: "نمونهٔ نمایشی — نظر مشتری واقعی نیست",
    review1: "سفارش‌دادن آسان بود و همه‌چیز را با پیام هماهنگ کردیم.",
    review2: "در موبایل راحت توانستم محصول را پیدا کنم.",
    review3: "قیمت پیش از تأیید سفارش روشن بود.",
    faqTitle: "پرسش‌های رایج",
    faq1: "برای خرید باید حساب بسازم؟",
    faq1a:
      "نه. خرید به‌صورت مهمان است. نام و شمارهٔ تماس را در فرم سفارش می‌نویسی.",
    faq2: "چطور پرداخت و تحویل را هماهنگ کنم؟",
    faq2a:
      "پس از ثبت درخواست، فروشگاه دربارهٔ روش تحویل و پرداخت با تو تماس می‌گیرد؛ پرداخت آنلاین در این نسخه فعال نیست.",
    faq3: "چطور در واتس‌اپ سفارش بدهم؟",
    faq3a:
      "پس از تنظیم شمارهٔ فروشگاه، دکمهٔ واتس‌اپ سفارش را مستقیم به گفت‌وگو می‌برد.",
    about: "یک جرعهٔ آرامش، هر جا که روز تو را می‌برد.",
    admin: "ورود مدیر فروشگاه",
    footerNote: "فلاسک و وسایل چای؛ با سفارش ساده و پشتیبانی مستقیم.",
    cart: "سبد خرید",
    emptyCart: "سبدت فعلاً خالی است",
    emptyCartBody: "یک فلاسک یا وسیلهٔ چای به سبد اضافه کن.",
    continue: "بازگشت به فروشگاه",
    subtotal: "جمع سفارش",
    checkout: "ثبت سفارش مهمان",
    noAccount: "برای خرید حساب کاربری لازم نیست",
    customerName: "نام و تخلص",
    phone: "شمارهٔ تماس",
    province: "ولایت",
    city: "شهر / ولسوالی",
    address: "نشانی تحویل",
    note: "یادداشت (اختیاری)",
    orderNow: "ثبت درخواست سفارش",
    waCheckout: "فرستادن سبد به واتس‌اپ",
    deliveryNote:
      "پرداخت و زمان تحویل را فروشگاه پس از تماس با شما تأیید می‌کند.",
    placing: "در حال ثبت…",
    orderSuccess: "درخواست سفارش ثبت شد",
    orderRef: "شمارهٔ پیگیری",
    orderSuccessBody:
      "فروشگاه برای هماهنگی تحویل و پرداخت با شما تماس می‌گیرد.",
    backShop: "ادامهٔ خرید",
    whatsappUnset: "شمارهٔ واتس‌اپ فروشگاه هنوز تنظیم نشده است.",
    networkError:
      "سفارش در فروشگاه ثبت نشد. لطفاً از واتس‌اپ با فروشگاه تماس بگیرید یا بعداً دوباره امتحان کنید.",
    seeProduct: "مشاهدهٔ کالا",
    categories: "دسته‌بندی‌ها",
    sort: "مرتب‌سازی",
    sortFeatured: "پیشنهادی",
    sortLow: "ارزان‌تر",
    sortHigh: "گران‌تر",
    productCount: "کالا",
    loading: "در حال آماده‌سازی فروشگاه…",
    notFound: "این کالا پیدا نشد.",
    back: "بازگشت",
    qty: "تعداد",
    shopNotice: "ارسال و پرداخت با هماهنگی مستقیم فروشگاه",
  },
  en: {
    shop: "Shop",
    story: "Why Kareem Store",
    faq: "FAQs",
    search: "Search flasks & tea gear",
    all: "All",
    thermos: "Flasks",
    tea: "Tea flasks",
    travel: "For the road",
    heroEyebrow: "Good tea, a companion for every day",
    heroTitle: "For the road. For slower days.",
    heroBody:
      "Find a flask that makes your day a little easier. No account required—just a simple order and a direct line to the shop.",
    browse: "Explore the shop",
    whatsapp: "Order on WhatsApp",
    newLabel: "A considered collection",
    collectionTitle: "Made for your moments",
    collectionBody:
      "From the first morning cup to the road home. Browse, choose and order without the fuss.",
    featured: "Chosen for you",
    seeAll: "See everything",
    add: "Add to bag",
    details: "Details",
    demo: "Sample details & price · verify before sale",
    sample: "Demo",
    capacity: "Capacity",
    origin: "Country of origin",
    dimensions: "Dimensions",
    material: "Material",
    insulation: "Insulation",
    colors: "Colours",
    brand: "Brand / maker",
    stock: "Sample stock",
    stockOut: "Out of stock",
    benefits: "A simpler way to shop",
    benefit1: "No account",
    benefit1Text:
      "Find your flask, leave your contact details, and you are done.",
    benefit2: "Clear pricing",
    benefit2Text: "See each price and your order total before you submit.",
    benefit3: "A real conversation",
    benefit3Text: "Speak directly with the shop about your order.",
    testimonial: "Kind words",
    testimonialNote: "Illustrative sample — not a real customer review",
    review1: "Ordering was easy, and we arranged everything by message.",
    review2: "I found what I needed easily on my phone.",
    review3: "The full price was clear before I sent my order.",
    faqTitle: "Good to know",
    faq1: "Do I need an account to order?",
    faq1a:
      "No. Checkout is for guests. Just leave your name and contact number.",
    faq2: "How do payment and delivery work?",
    faq2a:
      "The shop will contact you to agree on delivery and payment. Online payment is not enabled in this version.",
    faq3: "How can I use WhatsApp?",
    faq3a:
      "Once the shop number is set, the WhatsApp button opens a direct conversation.",
    about: "A little calm, wherever the day takes you.",
    admin: "Shop manager sign in",
    footerNote:
      "Flasks and tea essentials, with simple ordering and a direct line to the shop.",
    cart: "Your bag",
    emptyCart: "Your bag is taking a break",
    emptyCartBody: "Add a flask or tea essential to get started.",
    continue: "Back to the shop",
    subtotal: "Order total",
    checkout: "Guest checkout",
    noAccount: "No account needed to order",
    customerName: "Full name",
    phone: "Contact number",
    province: "Province",
    city: "City / district",
    address: "Delivery address",
    note: "Note (optional)",
    orderNow: "Send order request",
    waCheckout: "Send this bag on WhatsApp",
    deliveryNote:
      "The shop will confirm payment and delivery time when they contact you.",
    placing: "Sending…",
    orderSuccess: "Order request received",
    orderRef: "Reference",
    orderSuccessBody:
      "The shop will contact you to confirm delivery and payment.",
    backShop: "Continue shopping",
    whatsappUnset: "The shop WhatsApp number has not been set yet.",
    networkError:
      "The shop did not receive this order. Please contact the shop on WhatsApp or try again later.",
    seeProduct: "View item",
    categories: "Categories",
    sort: "Sort by",
    sortFeatured: "Recommended",
    sortLow: "Price: low to high",
    sortHigh: "Price: high to low",
    productCount: "items",
    loading: "Opening the shop…",
    notFound: "We could not find that item.",
    back: "Back",
    qty: "Quantity",
    shopNotice: "Delivery and payment arranged directly with the shop",
  },
} as const;

type Copy = { [Key in keyof typeof words.fa]: string };
const LocaleContext = createContext<{
  locale: Locale;
  setLocale: (value: Locale) => void;
  t: Copy;
}>({ locale: "fa", setLocale: () => {}, t: words.fa });
export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    try {
      return localStorage.getItem("thermora-locale") === "en" ? "en" : "fa";
    } catch {
      return "fa";
    }
  });
  const setLocale = (value: Locale) => {
    setLocaleState(value);
    try {
      localStorage.setItem("thermora-locale", value);
    } catch {}
  };
  useEffect(() => {
    document.documentElement.lang = locale === "fa" ? "fa-AF" : "en";
    document.documentElement.dir = locale === "fa" ? "rtl" : "ltr";
  }, [locale]);
  const value = useMemo(
    () => ({ locale, setLocale, t: words[locale] }),
    [locale]
  );
  return (
    <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>
  );
}
export const useLocale = () => useContext(LocaleContext);
