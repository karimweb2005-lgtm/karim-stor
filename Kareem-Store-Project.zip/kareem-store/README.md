# Kareem Store | کریم ستور

An Afghan-first bilingual storefront for flasks and tea gear. Built on the Manus Webdev starter: React, Vite, TypeScript, Wouter, Express, tRPC, Drizzle and MySQL.

## Shopper experience

The store opens in Dari with a right-to-left layout; the language toggle switches the interface to English and left-to-right. Shoppers can browse, search, filter by category, sort by price, view product details, keep a cart on their device and place a guest order. **Customers do not need an account or login to buy.** Afghanistan's 34 provinces appear in the delivery form. Order requests are stored with contact and delivery details; the shop confirms payment and delivery directly. No payment provider is configured, so the site does not claim to accept online payments.

A WhatsApp order link appears only after the shop owner adds a real number, including country code, in the private manager's **Shop settings**. The initial number is intentionally blank; customers are never sent to a fabricated recipient. A WhatsApp message is a separate action from saving an order.

## Manager experience

`/login` is the manager sign-in page; `/admin` is the private shop desk. Manus OAuth and server-side `adminProcedure` checks protect product creation, editing/removal, images, inventory, order/customer data and shop settings. Customers do not use this login.

The server grants the `admin` role only to the Manus identity matching `OWNER_OPEN_ID`. Set that environment variable to the shop owner's verified identity in the Webdev project runtime before manager access. We do not make the first login an admin; on a public site that would let a shopper take control. Without the owner mapping, login may succeed while management remains denied. Never open the store for public sales until the role mapping has been verified.

## Demo data and trust

Four initial catalogue entries, their generated illustrations, specifications, stock and prices are fictional samples. The UI labels them demo/unverified; no manufacturer or country-of-origin fact is invented. The hero and all demo-gallery WebP files are bundled in `client/public/images/`, so the GitHub source copy can show its visuals independently. Sample products seed the catalogue only when it is empty and never overwrite edits on restart. Before selling, replace them with accurate images and verified maker, origin, capacity, dimensions, material, insulation, stock and AFN prices, then clear the demo flag. Review cards are clearly marked illustrative, not customer testimonials.

## Database and development

Migrations `drizzle/0001_thermora_store.sql` and `drizzle/0002_thermora_product_gallery.sql` add the store tables and optional photo-gallery field. They are additive; the gallery migration snapshots each current primary image and maps only unchanged original demo photos to the bundled paths. It does not replace edited product facts, prices, stock, customer orders or shop settings. The initialized Webdev project supplies `DATABASE_URL`, Manus OAuth configuration and runtime service credentials. Apply unfinished migrations after schema changes:

```sh
pnpm install
pnpm db:migrate
pnpm dev
```

Checks: `pnpm check`, `pnpm test`, and `pnpm build`. For an independent local environment, copy `.env.example` to `.env` and set its values privately. Do not commit `.env`, credentials or customer exports. Managers can maintain up to eight photos per product: built-in demo WebPs live in version control; new uploads are size/type checked, restricted to authenticated admins and use durable project storage. An unavailable storage service produces a clear error rather than a temporary link.

## Code map

- `client/src/pages/`: storefront, product details, manager sign-in and desk.
- `client/src/components/`: product cards, store header and guest cart/checkout.
- `client/src/contexts/`: browser cart; `client/src/lib/i18n.tsx`: Dari/English and direction switch.
- `server/routers.ts`: public store/order APIs and admin-only APIs; `server/db.ts`: persistence and empty-catalog demo seed.
- `drizzle/schema.ts`, `drizzle/0001_thermora_store.sql`, `drizzle/0002_thermora_product_gallery.sql`: schema and additive migrations.
- `client/public/images/`: original fictional hero and demo gallery photographs used directly by the portable source bundle.
- `shared/products.ts`: marked demo records; `client/public/manus-routes.json`: page-route manifest.
- `plan.md`, `TODO.md`: design direction and preserved acceptance requirements.

## GitHub review

The delivered source ZIP preserves the separate project files and folders for collaborators to review; every bundled hero, story and demo-product image it references is included under `client/public/images/`. Project-specific uploads stay in Manus storage and are not copied into the archive. Keep real customer orders, owner identifiers, personal phone numbers and credentials out of commits and issue reports. Demo images and sample product details are not verified commercial claims.
