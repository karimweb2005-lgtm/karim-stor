export type ProductCategory = "thermos" | "tea" | "travel";

export type CatalogProduct = {
  slug: string;
  nameFa: string;
  nameEn: string;
  descriptionFa: string;
  descriptionEn: string;
  brandFa: string;
  brandEn: string;
  originFa: string;
  originEn: string;
  capacityMl: number;
  dimensionsFa: string;
  dimensionsEn: string;
  materialFa: string;
  materialEn: string;
  insulationFa: string;
  insulationEn: string;
  colorsFa: string;
  colorsEn: string;
  price: number;
  stock: number;
  imageUrl: string;
  galleryUrls?: string[] | null;
  category: ProductCategory;
  featured: boolean;
  isDemo: boolean;
  createdAt?: Date;
};

/** All initial catalogue facts, brands and prices are fictional demonstration data. */
export const DEMO_PRODUCTS: CatalogProduct[] = [
  {
    slug: "darya-green-flask",
    nameFa: "فلاسک دریا",
    nameEn: "Darya Everyday Flask",
    descriptionFa:
      "یک نمونهٔ نمایشی برای چایِ راه و روزهای پررفت‌وآمد. پیش از فروش واقعی، مشخصات و قیمت را با کالای واقعی برابر کنید.",
    descriptionEn:
      "A demo listing for tea on the move. Replace every sample specification and price before real sales.",
    brandFa: "نمونهٔ فروشگاه · سازنده تأیید نشده",
    brandEn: "Demo store label · maker unverified",
    originFa: "کشور سازنده: تأیید نشده (دمو)",
    originEn: "Country of origin: unverified demo data",
    capacityMl: 650,
    dimensionsFa: "نمونه: ۲۸ × ۸ × ۸ سانتی‌متر",
    dimensionsEn: "Sample: 28 × 8 × 8 cm",
    materialFa: "جنس: تأیید نشده (دمو)",
    materialEn: "Material: unverified demo data",
    insulationFa: "کارکرد عایق: تأیید نشده (دمو)",
    insulationEn: "Insulation: unverified demo data",
    colorsFa: "سبز جنگلی، کرم گرم",
    colorsEn: "Forest green, warm cream",
    price: 2450,
    stock: 8,
    imageUrl: "/images/products/darya-green.webp",
    galleryUrls: [
      "/images/products/darya-green.webp",
      "/images/products/darya-green-detail.webp",
    ],
    category: "thermos",
    featured: true,
    isDemo: true,
  },
  {
    slug: "sahar-cream-flask",
    nameFa: "فلاسک سپیده",
    nameEn: "Sahar Morning Flask",
    descriptionFa:
      "رنگ روشن و اندازهٔ روزانه در یک تصویر نمونه؛ اطلاعات این مدل تا جایگزینی با محصول واقعی تأیید نشده است.",
    descriptionEn:
      "A light-coloured, everyday-sized demo. This fictional product record is not manufacturer-verified.",
    brandFa: "نمونهٔ فروشگاه · سازنده تأیید نشده",
    brandEn: "Demo store label · maker unverified",
    originFa: "کشور سازنده: تأیید نشده (دمو)",
    originEn: "Country of origin: unverified demo data",
    capacityMl: 500,
    dimensionsFa: "نمونه: ۲۴ × ۷ × ۷ سانتی‌متر",
    dimensionsEn: "Sample: 24 × 7 × 7 cm",
    materialFa: "جنس: تأیید نشده (دمو)",
    materialEn: "Material: unverified demo data",
    insulationFa: "کارکرد عایق: تأیید نشده (دمو)",
    insulationEn: "Insulation: unverified demo data",
    colorsFa: "کرم گرم، ذغالی",
    colorsEn: "Warm cream, charcoal",
    price: 2100,
    stock: 12,
    imageUrl: "/images/products/sahar-cream.webp",
    galleryUrls: [
      "/images/products/sahar-cream.webp",
      "/images/products/sahar-cream-detail.webp",
    ],
    category: "thermos",
    featured: true,
    isDemo: true,
  },
  {
    slug: "shabnam-tea-infuser",
    nameFa: "فلاسک چای شبنم",
    nameEn: "Shabnam Tea Infuser Flask",
    descriptionFa:
      "طرح نمونه با فضای دم‌آوری چای؛ وجود صافی و ویژگی‌های محصول واقعی باید پیش از نشر بررسی شود.",
    descriptionEn:
      "A sample tea-flask concept; verify its infuser and real-product features before listing for sale.",
    brandFa: "نمونهٔ فروشگاه · سازنده تأیید نشده",
    brandEn: "Demo store label · maker unverified",
    originFa: "کشور سازنده: تأیید نشده (دمو)",
    originEn: "Country of origin: unverified demo data",
    capacityMl: 450,
    dimensionsFa: "نمونه: ۲۲ × ۷ × ۷ سانتی‌متر",
    dimensionsEn: "Sample: 22 × 7 × 7 cm",
    materialFa: "جنس: تأیید نشده (دمو)",
    materialEn: "Material: unverified demo data",
    insulationFa: "کارکرد عایق: تأیید نشده (دمو)",
    insulationEn: "Insulation: unverified demo data",
    colorsFa: "ذغالی، سبز جنگلی",
    colorsEn: "Charcoal, forest green",
    price: 2750,
    stock: 5,
    imageUrl: "/images/products/shabnam-tea.webp",
    galleryUrls: [
      "/images/products/shabnam-tea.webp",
      "/images/products/shabnam-tea-detail.webp",
    ],
    category: "tea",
    featured: true,
    isDemo: true,
  },
  {
    slug: "rah-travel-cup",
    nameFa: "پیالهٔ سفری ره",
    nameEn: "Rah Travel Cup",
    descriptionFa:
      "یک نمونهٔ خیالی برای نوشیدنی در مسیر؛ برای فروش، اطلاعات، موجودی و قیمت را مدیر فروشگاه تکمیل کند.",
    descriptionEn:
      "An illustrative travel-cup listing. The shop manager must replace sample details, stock and price before sale.",
    brandFa: "نمونهٔ فروشگاه · سازنده تأیید نشده",
    brandEn: "Demo store label · maker unverified",
    originFa: "کشور سازنده: تأیید نشده (دمو)",
    originEn: "Country of origin: unverified demo data",
    capacityMl: 350,
    dimensionsFa: "نمونه: ۱۶ × ۸ × ۸ سانتی‌متر",
    dimensionsEn: "Sample: 16 × 8 × 8 cm",
    materialFa: "جنس: تأیید نشده (دمو)",
    materialEn: "Material: unverified demo data",
    insulationFa: "کارکرد عایق: تأیید نشده (دمو)",
    insulationEn: "Insulation: unverified demo data",
    colorsFa: "سبز جنگلی، ذغالی",
    colorsEn: "Forest green, charcoal",
    price: 1650,
    stock: 15,
    imageUrl: "/images/products/rah-travel.webp",
    galleryUrls: [
      "/images/products/rah-travel.webp",
      "/images/products/rah-travel-detail.webp",
    ],
    category: "travel",
    featured: false,
    isDemo: true,
  },
];

export const DEFAULT_SETTINGS = {
  storeNameFa: "ترمورا",
  storeNameEn: "Thermora",
  whatsappNumber: "",
  noticeFa:
    "برای هماهنگی تحویل و پرداخت، پس از ثبت سفارش با شما تماس می‌گیریم.",
  noticeEn:
    "We will contact you to confirm delivery and payment after your order.",
};
