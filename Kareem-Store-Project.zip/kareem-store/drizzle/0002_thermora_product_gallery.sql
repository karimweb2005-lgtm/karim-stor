ALTER TABLE `products` ADD `galleryUrls` json;
--> statement-breakpoint

-- Restore self-contained image paths only for the untouched fictional demo rows created by the prior seed.
-- Existing merchandise, modified demo rows, stock, orders and settings remain unchanged.
UPDATE `products`
SET `galleryUrls` = CASE
  WHEN `slug` = 'darya-green-flask' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-2.webp'
    THEN JSON_ARRAY('/images/products/darya-green.webp', '/images/products/darya-green-detail.webp')
  WHEN `slug` = 'sahar-cream-flask' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-3.webp'
    THEN JSON_ARRAY('/images/products/sahar-cream.webp', '/images/products/sahar-cream-detail.webp')
  WHEN `slug` = 'shabnam-tea-infuser' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-4.webp'
    THEN JSON_ARRAY('/images/products/shabnam-tea.webp', '/images/products/shabnam-tea-detail.webp')
  WHEN `slug` = 'rah-travel-cup' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-5.webp'
    THEN JSON_ARRAY('/images/products/rah-travel.webp', '/images/products/rah-travel-detail.webp')
  ELSE JSON_ARRAY(`imageUrl`)
END
WHERE `galleryUrls` IS NULL;
--> statement-breakpoint

-- Promote the matching untouched fictional demo primary paths only after the snapshots are safe.
UPDATE `products`
SET `imageUrl` = CASE
  WHEN `slug` = 'darya-green-flask' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-2.webp'
    THEN '/images/products/darya-green.webp'
  WHEN `slug` = 'sahar-cream-flask' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-3.webp'
    THEN '/images/products/sahar-cream.webp'
  WHEN `slug` = 'shabnam-tea-infuser' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-4.webp'
    THEN '/images/products/shabnam-tea.webp'
  WHEN `slug` = 'rah-travel-cup' AND `isDemo` = 1 AND `imageUrl` = '/manus-storage/async-images/PL1YJbQoV6UOmYAJLPm0Gz/image-5.webp'
    THEN '/images/products/rah-travel.webp'
  ELSE `imageUrl`
END
WHERE `isDemo` = 1
  AND `slug` IN ('darya-green-flask', 'sahar-cream-flask', 'shabnam-tea-infuser', 'rah-travel-cup');
