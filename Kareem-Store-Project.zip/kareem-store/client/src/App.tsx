import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { lazy, Suspense } from "react";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { CartProvider } from "./contexts/CartContext";
import { LocaleProvider } from "./lib/i18n";
import Home from "./pages/Home";
import LoginPage from "./pages/Login";

const AdminPage = lazy(() => import("./pages/Admin"));
const ProductPage = lazy(() => import("./pages/Product"));

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/product/:slug" component={ProductPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <LocaleProvider>
          <CartProvider>
            <TooltipProvider>
              <Toaster />
              <Suspense
                fallback={
                  <div
                    className="page-loading"
                    role="status"
                    aria-live="polite"
                  >
                    در حال بارگذاری…
                  </div>
                }
              >
                <Router />
              </Suspense>
            </TooltipProvider>
          </CartProvider>
        </LocaleProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
