import { Minus, Plus, Trash2, X } from "lucide-react";
import { useMemo, useState, type FormEvent } from "react";
import type { CatalogProduct } from "../../../shared/products";
import { DEMO_PRODUCTS } from "../../../shared/products";
import { trpc } from "@/lib/trpc";
import { useCart } from "@/contexts/CartContext";
import { useLocale } from "@/lib/i18n";
import { money } from "./ProductCard";

const provinces = [
  ["Badakhshan", "بدخشان"],
  ["Badghis", "بادغیس"],
  ["Baghlan", "بغلان"],
  ["Balkh", "بلخ"],
  ["Bamyan", "بامیان"],
  ["Daykundi", "دایکندی"],
  ["Farah", "فراه"],
  ["Faryab", "فاریاب"],
  ["Ghazni", "غزنی"],
  ["Ghor", "غور"],
  ["Helmand", "هلمند"],
  ["Herat", "هرات"],
  ["Jowzjan", "جوزجان"],
  ["Kabul", "کابل"],
  ["Kandahar", "کندهار"],
  ["Kapisa", "کاپیسا"],
  ["Khost", "خوست"],
  ["Kunar", "کنر"],
  ["Kunduz", "کندز"],
  ["Laghman", "لغمان"],
  ["Logar", "لوگر"],
  ["Nangarhar", "ننگرهار"],
  ["Nimruz", "نیمروز"],
  ["Nuristan", "نورستان"],
  ["Paktia", "پکتیا"],
  ["Paktika", "پکتیکا"],
  ["Panjshir", "پنجشیر"],
  ["Parwan", "پروان"],
  ["Samangan", "سمنگان"],
  ["Sar-e Pol", "سرپل"],
  ["Takhar", "تخار"],
  ["Uruzgan", "ارزگان"],
  ["Wardak", "میدان وردک"],
  ["Zabul", "زابل"],
] as const;

const splitVariants = (value: string) =>
  value
    .split(/[،,]/)
    .map(color => color.trim())
    .filter(Boolean);

export function CartDrawer() {
  const { locale, t } = useLocale();
  const cart = useCart();
  const [showCheckout, setShowCheckout] = useState(false);
  const [success, setSuccess] = useState<{
    orderCode: string;
    total: number;
  } | null>(null);
  const [error, setError] = useState("");
  const productsQuery = trpc.store.products.useQuery(undefined, {
    placeholderData: DEMO_PRODUCTS as CatalogProduct[],
  });
  const settingsQuery = trpc.store.settings.useQuery();
  const products = productsQuery.data ?? DEMO_PRODUCTS;
  const bySlug = useMemo(
    () => new Map(products.map(item => [item.slug, item])),
    [products]
  );
  const rows = cart.lines
    .map(line => ({ ...line, product: bySlug.get(line.slug) }))
    .filter((line): line is typeof line & { product: CatalogProduct } =>
      Boolean(line.product)
    );
  const total = rows.reduce(
    (sum, line) => sum + line.quantity * line.product.price,
    0
  );
  const order = trpc.store.placeOrder.useMutation();
  const phone = settingsQuery.data?.whatsappNumber ?? "";
  const waNumber = phone.replace(/\D/g, "");
  const close = () => {
    cart.close();
    setShowCheckout(false);
    setSuccess(null);
    setError("");
  };
  const sendWhatsApp = (form?: HTMLFormElement) => {
    if (!waNumber || rows.length === 0) {
      setError(t.whatsappUnset);
      return;
    }
    const formData = form ? new FormData(form) : null;
    const name = String(formData?.get("customerName") ?? "").trim();
    const customerDetails = formData
      ? [
          [locale === "fa" ? "شماره" : "Phone", formData.get("phone")],
          [locale === "fa" ? "ولایت" : "Province", formData.get("province")],
          [
            locale === "fa" ? "شهر/ولسوالی" : "City/district",
            formData.get("city"),
          ],
          [locale === "fa" ? "نشانی" : "Address", formData.get("address")],
          [locale === "fa" ? "یادداشت" : "Note", formData.get("note")],
        ]
          .filter(
            (entry): entry is [string, FormDataEntryValue] =>
              typeof entry[1] === "string" && Boolean(entry[1].trim())
          )
          .map(([label, value]) => `${label}: ${value}`)
      : [];
    const lines = rows.map(
      row =>
        `${locale === "fa" ? row.product.nameFa : row.product.nameEn}${
          row.color
            ? ` · ${(() => {
                const variants = splitVariants(
                  locale === "fa" ? row.product.colorsFa : row.product.colorsEn
                );
                const index = row.product.colorsEn
                  .split(/[،,]/)
                  .map(color => color.trim())
                  .indexOf(row.color);
                return variants[index] ?? row.color;
              })()}`
            : ""
        } × ${row.quantity} — ${money(row.quantity * row.product.price, locale)}`
    );
    const greeting =
      locale === "fa"
        ? `سلام، می‌خواهم این سفارش را هماهنگ کنم:\n${lines.join("\n")}\nجمع نمونه: ${money(total, locale)}${name ? `\nنام: ${name}` : ""}${customerDetails.length ? `\n${customerDetails.join("\n")}` : ""}`
        : `Hello, I'd like to arrange this order:\n${lines.join("\n")}\nSample total: ${money(total, locale)}${name ? `\nName: ${name}` : ""}${customerDetails.length ? `\n${customerDetails.join("\n")}` : ""}`;
    window.open(
      `https://wa.me/${waNumber}?text=${encodeURIComponent(greeting)}`,
      "_blank",
      "noopener,noreferrer"
    );
  };
  const submitOrder = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    const data = new FormData(event.currentTarget);
    try {
      const result = await order.mutateAsync({
        customerName: String(data.get("customerName") ?? ""),
        phone: String(data.get("phone") ?? ""),
        province: String(data.get("province") ?? ""),
        city: String(data.get("city") ?? ""),
        address: String(data.get("address") ?? ""),
        note: String(data.get("note") ?? ""),
        lines: rows.map(line => ({
          slug: line.slug,
          color: line.color,
          quantity: line.quantity,
        })),
      });
      setSuccess({ orderCode: result.orderCode, total: result.total });
      cart.clear();
      void productsQuery.refetch();
    } catch {
      setError(t.networkError);
    }
  };

  const sendSuccessToWhatsApp = () => {
    if (!waNumber || !success) return;
    const text =
      locale === "fa"
        ? `سلام، برای هماهنگی سفارش ${success.orderCode} پیام می‌دهم. جمع سفارش: ${money(success.total, locale)}.`
        : `Hello, I am following up on order ${success.orderCode}. Total: ${money(success.total, locale)}.`;
    window.open(
      `https://wa.me/${waNumber}?text=${encodeURIComponent(text)}`,
      "_blank",
      "noopener,noreferrer"
    );
  };

  if (!cart.isOpen) return null;
  return (
    <div
      className="drawer-scrim"
      role="presentation"
      onMouseDown={event => {
        if (event.target === event.currentTarget) close();
      }}
    >
      <aside
        className="cart-drawer"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-title"
      >
        <div className="cart-head">
          <div>
            <span className="eyebrow">KAREEM STORE · {t.shop}</span>
            <h2 id="cart-title">{success ? t.orderSuccess : t.cart}</h2>
          </div>
          <button className="icon-btn" onClick={close} aria-label={t.back}>
            <X />
          </button>
        </div>
        {success ? (
          <div className="order-success">
            <span className="success-seal">✓</span>
            <h3>{t.orderSuccess}</h3>
            <p>{t.orderSuccessBody}</p>
            <div className="order-reference">
              <span>{t.orderRef}</span>
              <strong>{success.orderCode}</strong>
              <b>{money(success.total, locale)}</b>
            </div>
            {waNumber && (
              <button
                className="button button-green full-button"
                onClick={sendSuccessToWhatsApp}
              >
                {t.whatsapp}
              </button>
            )}
            <button
              className="button button-outline full-button"
              onClick={close}
            >
              {t.backShop}
            </button>
          </div>
        ) : rows.length === 0 ? (
          <div className="empty-cart">
            <span className="empty-illustration">♨</span>
            <h3>{t.emptyCart}</h3>
            <p>{t.emptyCartBody}</p>
            <button className="button button-green" onClick={close}>
              {t.continue}
            </button>
          </div>
        ) : (
          <>
            <div className="cart-items">
              {rows.map(({ slug, color, quantity, product }) => (
                <div className="cart-item" key={`${slug}:${color}`}>
                  <img src={product.imageUrl} alt="" />
                  <div className="cart-item-copy">
                    <strong>
                      {locale === "fa" ? product.nameFa : product.nameEn}
                    </strong>
                    <small>{money(product.price, locale)}</small>
                    {color && (
                      <small>
                        {locale === "fa" ? "رنگ" : "Colour"}:{" "}
                        {(() => {
                          const en = product.colorsEn
                            .split(/[،,]/)
                            .map(value => value.trim());
                          const fa = product.colorsFa
                            .split(/[،,]/)
                            .map(value => value.trim());
                          const index = en.indexOf(color);
                          return locale === "fa" ? (fa[index] ?? color) : color;
                        })()}
                      </small>
                    )}
                    <div className="qty-control">
                      <button
                        onClick={() =>
                          cart.setQuantity(slug, color, quantity - 1)
                        }
                        aria-label="کاهش"
                      >
                        <Minus size={13} />
                      </button>
                      <span>{quantity}</span>
                      <button
                        disabled={quantity >= Math.min(20, product.stock)}
                        onClick={() =>
                          cart.setQuantity(
                            slug,
                            color,
                            Math.min(20, product.stock, quantity + 1)
                          )
                        }
                        aria-label="افزایش"
                      >
                        <Plus size={13} />
                      </button>
                    </div>
                  </div>
                  <button
                    className="remove-item"
                    onClick={() => cart.remove(slug, color)}
                    aria-label="حذف"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
            <div className="cart-bottom">
              <div className="cart-total">
                <span>{t.subtotal}</span>
                <strong>{money(total, locale)}</strong>
              </div>
              <small className="cart-demo-note">{t.demo}</small>
              {!showCheckout ? (
                <>
                  <button
                    className="button button-green full-button"
                    onClick={() => setShowCheckout(true)}
                  >
                    {t.checkout}
                    <span>→</span>
                  </button>
                  {waNumber ? (
                    <button
                      className="button button-outline full-button"
                      onClick={() => sendWhatsApp()}
                    >
                      {t.waCheckout}
                    </button>
                  ) : (
                    <p className="wa-unset-note">{t.whatsappUnset}</p>
                  )}
                </>
              ) : (
                <form className="checkout-form" onSubmit={submitOrder}>
                  <p className="no-account-note">{t.noAccount}</p>
                  <label>
                    {t.customerName}
                    <input
                      name="customerName"
                      required
                      minLength={2}
                      autoComplete="name"
                    />
                  </label>
                  <label>
                    {t.phone}
                    <input
                      name="phone"
                      required
                      minLength={8}
                      inputMode="tel"
                      autoComplete="tel"
                      placeholder="+93 …"
                    />
                  </label>
                  <div className="form-row">
                    <label>
                      {t.province}
                      <select name="province" defaultValue="" required>
                        <option value="" disabled>
                          {locale === "fa"
                            ? "ولایت را انتخاب کنید"
                            : "Choose province"}
                        </option>
                        {provinces.map(([en, fa]) => (
                          <option value={locale === "fa" ? fa : en} key={en}>
                            {locale === "fa" ? fa : en}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      {t.city}
                      <input name="city" required />
                    </label>
                  </div>
                  <label>
                    {t.address}
                    <textarea
                      name="address"
                      required
                      rows={2}
                      autoComplete="street-address"
                    />
                  </label>
                  <label>
                    {t.note}
                    <textarea name="note" rows={2} />
                  </label>
                  <p className="delivery-note">{t.deliveryNote}</p>
                  {error && (
                    <p className="form-error" role="alert">
                      {error}
                    </p>
                  )}
                  <button
                    className="button button-green full-button"
                    type="submit"
                    disabled={order.isPending}
                  >
                    {order.isPending ? t.placing : t.orderNow}
                  </button>
                  {waNumber ? (
                    <button
                      className="button button-outline full-button"
                      type="button"
                      onClick={event =>
                        sendWhatsApp(event.currentTarget.form ?? undefined)
                      }
                    >
                      {t.waCheckout}
                    </button>
                  ) : (
                    <small className="wa-unset-note">{t.whatsappUnset}</small>
                  )}
                </form>
              )}
              <p className="secure-note">{t.deliveryNote}</p>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
