import { ArrowUpRight, Plus } from "lucide-react";
import type { CatalogProduct } from "../../../shared/products";
import { useCart } from "@/contexts/CartContext";
import { useLocale } from "@/lib/i18n";
import { Link } from "wouter";

export function money(amount: number, locale: "fa" | "en") {
  const digits = new Intl.NumberFormat(locale === "fa" ? "fa-AF" : "en-AF", {
    maximumFractionDigits: 0,
  }).format(amount);
  return locale === "fa" ? `${digits} ؋` : `؋ ${digits}`;
}

export function ProductCard({
  product,
  index = 0,
}: {
  product: CatalogProduct;
  index?: number;
}) {
  const { locale, t } = useLocale();
  const cart = useCart();
  const name = locale === "fa" ? product.nameFa : product.nameEn;
  const detail =
    locale === "fa" ? product.descriptionFa : product.descriptionEn;
  const defaultColor =
    product.colorsEn
      .split(/[،,]/)
      .map(color => color.trim())
      .filter(Boolean)[0] ?? "";
  return (
    <article className={`product-card reveal reveal-delay-${index % 4}`}>
      <Link
        href={`/product/${product.slug}`}
        className="product-photo-link"
        aria-label={`${t.seeProduct}: ${name}`}
      >
        <div className="product-photo">
          <img src={product.imageUrl} alt={name} loading="lazy" />
          <span className="product-badge">
            {product.isDemo ? t.sample : product.featured ? t.featured : t.shop}
          </span>
          <span className="quick-view">
            <ArrowUpRight size={17} />
          </span>
        </div>
      </Link>
      <div className="product-info">
        <div className="product-heading">
          <Link href={`/product/${product.slug}`} className="product-name">
            {name}
          </Link>
          <span className="product-capacity">
            {new Intl.NumberFormat(locale === "fa" ? "fa-AF" : "en-AF").format(
              product.capacityMl
            )}{" "}
            ml
          </span>
        </div>
        <p className="product-description">{detail}</p>
        <div className="product-meta-row">
          <span>{locale === "fa" ? product.brandFa : product.brandEn}</span>
          <span className="demo-mark">
            {product.isDemo ? "• " + t.demo : ""}
          </span>
        </div>
        <div className="product-purchase">
          <div>
            <strong>{money(product.price, locale)}</strong>
            <small>
              {product.stock > 0
                ? `${t.stock}: ${new Intl.NumberFormat(locale === "fa" ? "fa-AF" : "en-AF").format(product.stock)}`
                : t.stockOut}
            </small>
          </div>
          <button
            className="add-product"
            disabled={product.stock < 1}
            onClick={() => {
              cart.add(product.slug, defaultColor);
              cart.open();
            }}
            aria-label={product.stock < 1 ? t.stockOut : `${t.add} — ${name}`}
            title={product.stock < 1 ? t.stockOut : t.add}
          >
            <Plus size={17} />
            <span>{product.stock > 0 ? t.add : t.stockOut}</span>
          </button>
        </div>
      </div>
    </article>
  );
}
