import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronLeft,
  ChevronRight,
  ShoppingBag,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useParams } from "wouter";
import { StoreHeader } from "@/components/StoreHeader";
import { money } from "@/components/ProductCard";
import { useCart } from "@/contexts/CartContext";
import { useLocale } from "@/lib/i18n";
import { DEMO_PRODUCTS, type CatalogProduct } from "../../../shared/products";
import { trpc } from "@/lib/trpc";

const splitColors = (value: string) =>
  value
    .split(/[،,]/)
    .map(color => color.trim())
    .filter(Boolean);

export default function ProductPage() {
  const { slug = "" } = useParams<{ slug: string }>();
  const { locale, t } = useLocale();
  const cart = useCart();
  const query = trpc.store.product.useQuery(
    { slug },
    {
      placeholderData: DEMO_PRODUCTS.find(product => product.slug === slug) as
        | CatalogProduct
        | undefined,
    }
  );
  const product = query.data;
  const [quantity, setQuantity] = useState(1);
  const [detailZoom, setDetailZoom] = useState(false);
  const [selectedImage, setSelectedImage] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const colorsEn = product ? splitColors(product.colorsEn) : [];
  const colorsFa = product ? splitColors(product.colorsFa) : [];
  const galleryImages = product
    ? [
        ...new Set(
          [product.imageUrl, ...(product.galleryUrls ?? [])].filter(Boolean)
        ),
      ]
    : [];
  useEffect(() => {
    if (colorsEn.length && !colorsEn.includes(selectedColor))
      setSelectedColor(colorsEn[0]);
  }, [product?.slug, product?.colorsEn, selectedColor]);
  useEffect(() => {
    setSelectedImage(product?.imageUrl ?? "");
    setDetailZoom(false);
  }, [product?.slug, product?.imageUrl]);

  if (query.isLoading && !product)
    return <div className="page-loading">{t.loading}</div>;
  if (!product)
    return (
      <div className="site-shell">
        <StoreHeader />
        <main className="not-found-state">
          <h1>{t.notFound}</h1>
          <Link href="/" className="button button-green">
            {t.back}
          </Link>
        </main>
      </div>
    );
  const name = locale === "fa" ? product.nameFa : product.nameEn;
  const activeImage = galleryImages.includes(selectedImage)
    ? selectedImage
    : product.imageUrl;
  const currentColorIndex = Math.max(0, colorsEn.indexOf(selectedColor));
  const selectedColorLabel =
    locale === "fa"
      ? (colorsFa[currentColorIndex] ?? "")
      : (colorsEn[currentColorIndex] ?? "");
  const details = [
    [t.brand, locale === "fa" ? product.brandFa : product.brandEn],
    [t.origin, locale === "fa" ? product.originFa : product.originEn],
    [
      t.capacity,
      `${new Intl.NumberFormat(locale === "fa" ? "fa-AF" : "en-AF").format(product.capacityMl)} ml`,
    ],
    [
      t.dimensions,
      locale === "fa" ? product.dimensionsFa : product.dimensionsEn,
    ],
    [t.material, locale === "fa" ? product.materialFa : product.materialEn],
    [
      t.insulation,
      locale === "fa" ? product.insulationFa : product.insulationEn,
    ],
    [
      t.stock,
      product.stock > 0
        ? new Intl.NumberFormat(locale === "fa" ? "fa-AF" : "en-AF").format(
            product.stock
          )
        : t.stockOut,
    ],
  ];

  return (
    <div className="site-shell">
      <StoreHeader />
      <main className="product-page page-section">
        <Link href="/#products" className="back-link">
          {locale === "fa" ? (
            <ChevronRight size={17} />
          ) : (
            <ChevronLeft size={17} />
          )}{" "}
          {t.back}
        </Link>
        <div className="product-detail-layout">
          <div className="detail-gallery">
            <button
              type="button"
              className={`detail-main-image ${detailZoom ? "zoomed" : ""}`}
              onClick={() => setDetailZoom(value => !value)}
              aria-label={
                locale === "fa"
                  ? "بزرگ‌نمایی تصویر کالا"
                  : "Toggle product photo zoom"
              }
            >
              <img src={activeImage} alt={name} />
              <span className="detail-demo-label">
                {product.isDemo ? t.demo : t.featured}
              </span>
            </button>
            <div
              className="detail-gallery-strip"
              role="group"
              aria-label={locale === "fa" ? "تصاویر کالا" : "Product photos"}
            >
              {galleryImages.map((image, index) => (
                <button
                  key={image}
                  type="button"
                  className={activeImage === image ? "active" : ""}
                  aria-pressed={activeImage === image}
                  onClick={() => {
                    setSelectedImage(image);
                    setDetailZoom(false);
                  }}
                >
                  <img src={image} alt="" />
                  <span>
                    {locale === "fa"
                      ? `نمای ${new Intl.NumberFormat("fa-AF").format(index + 1)}`
                      : `View ${index + 1}`}
                  </span>
                </button>
              ))}
            </div>
          </div>
          <div className="detail-copy">
            <span className="eyebrow">
              {locale === "fa" ? "کریم ستور · کابل" : "KAREEM STORE · KABUL"}
            </span>
            <h1>{name}</h1>
            <p className="detail-brand">
              {locale === "fa" ? product.brandFa : product.brandEn}
            </p>
            <p className="detail-description">
              {locale === "fa" ? product.descriptionFa : product.descriptionEn}
            </p>
            <div className="detail-price">
              <strong>{money(product.price, locale)}</strong>
              <span>
                {locale === "fa" ? "قیمت نمونه (AFN)" : "Sample price (AFN)"}
              </span>
            </div>
            <div className="detail-callout">
              <Check size={17} />
              <span>{t.demo}</span>
            </div>
            <div className="detail-color-picker">
              <div>
                <b>{t.colors}</b>
                <span>{selectedColorLabel}</span>
              </div>
              <div
                className="color-choice-list"
                role="group"
                aria-label={t.colors}
              >
                {colorsEn.map((color, index) => {
                  const label =
                    locale === "fa" ? (colorsFa[index] ?? color) : color;
                  return (
                    <button
                      key={color}
                      className={`color-choice ${selectedColor === color ? "selected" : ""}`}
                      aria-pressed={selectedColor === color}
                      onClick={() => setSelectedColor(color)}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="detail-buy-row">
              <div className="detail-quantity">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  aria-label={locale === "fa" ? "کاهش" : "Decrease"}
                >
                  −
                </button>
                <span>
                  {new Intl.NumberFormat(
                    locale === "fa" ? "fa-AF" : "en-AF"
                  ).format(quantity)}
                </span>
                <button
                  disabled={quantity >= Math.min(20, product.stock)}
                  onClick={() =>
                    setQuantity(Math.min(20, product.stock, quantity + 1))
                  }
                  aria-label={locale === "fa" ? "افزایش" : "Increase"}
                >
                  +
                </button>
              </div>
              <button
                className="button button-green detail-add"
                disabled={product.stock < 1}
                onClick={() => {
                  for (let i = 0; i < quantity; i++)
                    cart.add(product.slug, selectedColor);
                  cart.open();
                }}
              >
                <ShoppingBag size={17} />
                {product.stock > 0 ? t.add : t.stockOut}
              </button>
            </div>
            {product.stock < 1 && (
              <p className="out-of-stock-note">{t.stockOut}</p>
            )}
            <p className="guest-message">{t.noAccount}</p>
            <div className="detail-specs">
              <h2>{locale === "fa" ? "مشخصات کالا" : "Product details"}</h2>
              {details.map(([label, value]) => (
                <div key={label}>
                  <span>{label}</span>
                  <b>{value}</b>
                </div>
              ))}
            </div>
            <p className="detail-payment-note">{t.deliveryNote}</p>
          </div>
        </div>
        <section className="detail-next">
          <div>
            <span className="eyebrow">
              {locale === "fa" ? "یک انتخاب ساده" : "A simpler choice"}
            </span>
            <h2>{t.about}</h2>
          </div>
          <Link href="/" className="button button-outline">
            {t.browse}
            {locale === "fa" ? (
              <ArrowLeft size={16} />
            ) : (
              <ArrowRight size={16} />
            )}
          </Link>
        </section>
      </main>
    </div>
  );
}
