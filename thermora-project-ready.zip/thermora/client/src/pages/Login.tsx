import { ArrowLeft, ArrowRight, LockKeyhole, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { BrandMark } from "@/components/StoreHeader";
import { useLocale } from "@/lib/i18n";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

export default function LoginPage() {
  const { locale, setLocale } = useLocale();
  const english = locale === "en";
  const auth = trpc.auth.me.useQuery(undefined, { retry: false });
  const [error, setError] = useState("");
  const signIn = () => {
    try {
      setError("");
      startLogin();
    } catch {
      setError(
        english
          ? "Manager sign-in is not configured in this preview yet."
          : "ورود مدیر هنوز برای این پیش‌نمایش تنظیم نشده است."
      );
    }
  };
  const isAdmin = auth.data?.role === "admin";
  return (
    <main className="manager-login-page">
      <div className="login-top">
        <BrandMark />
        <button
          className="language-toggle"
          onClick={() => setLocale(english ? "fa" : "en")}
        >
          {english ? "دری" : "EN"}
        </button>
      </div>
      <div className="login-layout">
        <div className="login-art">
          <img src="/images/thermora-hero.webp" alt="" />
          <span className="login-art-shade" />
          <div className="login-art-caption">
            <span>THERMORA · KABUL</span>
            <h2>
              {english
                ? "Good things, thoughtfully kept."
                : "خوبی‌ها را با دل نگه‌دار."}
            </h2>
          </div>
        </div>
        <div className="login-card">
          <span className="login-icon">
            <LockKeyhole size={22} />
          </span>
          <span className="eyebrow">
            {english ? "THE SHOP DESK" : "میزِ مدیریت فروشگاه"}
          </span>
          <h1>{english ? "Manager sign in" : "ورود مدیر فروشگاه"}</h1>
          <p className="login-explainer">
            {english
              ? "This sign-in is for the shop manager only. Customers can browse and place an order without an account."
              : "این ورود فقط برای مدیر فروشگاه است. مشتریان می‌توانند بدون حساب محصولات را ببینند و سفارش ثبت کنند."}
          </p>
          {auth.isLoading ? (
            <div className="auth-status">
              {english ? "Checking your session…" : "در حال بررسی ورود…"}
            </div>
          ) : isAdmin ? (
            <div className="login-logged-in">
              <ShieldCheck size={19} />
              <span>
                {english
                  ? "You are signed in as a manager."
                  : "با دسترسی مدیر وارد شده‌اید."}
              </span>
              <Link className="button button-green full-button" href="/admin">
                {english ? "Open manager desk" : "رفتن به مدیریت"}
              </Link>
            </div>
          ) : auth.data ? (
            <div className="login-denied">
              <b>
                {english ? "Manager access required" : "دسترسی مدیر لازم است"}
              </b>
              <p>
                {english
                  ? "This account is not authorised to edit the store. Configure the shop owner identity in the project environment (OWNER_OPEN_ID) before signing in."
                  : "این حساب مجاز به مدیریت فروشگاه نیست. پیش از ورود، شناسهٔ صاحب فروشگاه را در تنظیمات پروژه (OWNER_OPEN_ID) تعیین کنید."}
              </p>
            </div>
          ) : (
            <button
              className="button button-green full-button login-submit"
              onClick={signIn}
            >
              <LockKeyhole size={17} />
              {english ? "Continue with Manus" : "ادامه با حساب مدیر"}
              <span>
                {english ? <ArrowRight size={17} /> : <ArrowLeft size={17} />}
              </span>
            </button>
          )}
          {error && (
            <p className="form-error" role="alert">
              {error}
            </p>
          )}
          <div className="login-divider">
            <span>{english ? "No customer login here" : "خریدِ مهمان"}</span>
          </div>
          <p className="login-note">
            {english
              ? "Shopping never asks for an account. Need help with an order? Use the WhatsApp button in the shop."
              : "برای خرید حساب لازم نیست. برای راهنمایی سفارش، از دکمهٔ واتس‌اپ در فروشگاه استفاده کنید."}
          </p>
          <Link href="/" className="login-back">
            {english ? "← Back to the shop" : "→ بازگشت به فروشگاه"}
          </Link>
        </div>
      </div>
      <p className="login-footer">
        {english
          ? "Private manager area · Your customer orders are protected"
          : "بخش خصوصی مدیر · اطلاعات سفارش مشتریان محافظت می‌شود"}
      </p>
    </main>
  );
}
